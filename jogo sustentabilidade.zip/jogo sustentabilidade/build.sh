#!/bin/sh
# Compila o nucleo em Rust para WebAssembly e coloca o .wasm junto da pagina.
set -e

cd "$(dirname "$0")"

if ! rustup target list --installed 2>/dev/null | grep -q wasm32-unknown-unknown; then
  echo "instalando o alvo wasm32-unknown-unknown..."
  rustup target add wasm32-unknown-unknown
fi

echo "compilando o jogo..."
cargo build --release --target wasm32-unknown-unknown

cp target/wasm32-unknown-unknown/release/sustentabilidade.wasm web/jogo.wasm
ls -lh web/jogo.wasm

echo
echo "pronto. Para jogar, abra um terminal nesta pasta e rode:"
echo "    ./serve.sh"
