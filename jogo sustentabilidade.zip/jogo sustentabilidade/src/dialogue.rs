//! Arvores de dialogo dos NPCs, com informacoes reais sobre Ivaipora - PR.

pub struct Node {
    pub speaker: &'static str,
    pub lines: &'static [&'static str],
    pub choices: &'static [&'static str],
    pub next: &'static [i32],
}

pub const NODES: &[Node] = &[
    // 0 - Dona Marta, raiz
    Node {
        speaker: "Dona Marta (feirante)",
        lines: &[
            "Oi, meu filho! Viu o tamanho da bagunca hoje na Praca Espanha? Apos a feira sobra de tudo no chao.",
            "Fico aqui todo domingo, no Largo Mal. Deodoro. O chafariz enche de imagem bonita, mas o lixo vem junto.",
        ],
        choices: &["Por que separar o lixo?", "O que vai na lixeira verde?", "Quem cuida da praca?", "Tchau!"],
        next: &[1, 2, 3, -1],
    },
    // 1
    Node {
        speaker: "Dona Marta",
        lines: &[
            "Porque o lixo todo junto vira chorume, mau cheiro e praga.",
            "Separado, cada material tem um destino util. E o catador ganha mais pelo material limpo.",
        ],
        choices: &["Entendi!", "Voltar"],
        next: &[-1, 0],
    },
    // 2
    Node {
        speaker: "Dona Marta",
        lines: &[
            "Na lixeira verde so vai comida: casca de banana, resto de arroz, pao amanhecido, folha seca.",
            "Isso vira adubo e alimenta a horta. Ainda hoje se joga fora muita comida que daria para comer.",
        ],
        choices: &["Voltar"],
        next: &[0],
    },
    // 3
    Node {
        speaker: "Dona Marta",
        lines: &[
            "A prefeitura cuida dos bancos e do chafariz, mas a varredura do chao e pouca.",
            "Quando falta coleta, quem limpa e a vizinhanca. E por isso que projeto escolar ajuda tanto.",
        ],
        choices: &["Voltar"],
        next: &[0],
    },
    // 4 - Seu Antonio, raiz
    Node {
        speaker: "Seu Antonio (aposentado, ex-catador)",
        lines: &[
            "Ja recolhi muito papel e muita latinha nessa regiao, meu filho.",
            "Ninguem olha pra mim com importance, mas a rua nao enche. O material que eu entrego nao vai para o aterro.",
        ],
        choices: &["Como posso ajudar?", "Por que e justo com catadores?", "Tchau"],
        next: &[5, 6, -1],
    },
    // 5
    Node {
        speaker: "Seu Antonio",
        lines: &[
            "Lave as embalagens antes de separar e nunca jogue na calcada.",
            "Bateria, pilha e eletronico tem posto especifico de coleta. Isso nunca vai no lixo comum.",
        ],
        choices: &["Voltar"],
        next: &[4],
    },
    // 6
    Node {
        speaker: "Seu Antonio",
        lines: &[
            "Porque sem material nao tem renda. Coleta seletiva e questao de justo, nao de favor.",
            "Quando o caminhao passa recolhendo separado, o preco do que a gente vende melhora.",
        ],
        choices: &["Voltar"],
        next: &[4],
    },
    // 7 - Bia, raiz
    Node {
        speaker: "Bia (estudante do Clube de Ciencias)",
        lines: &[
            "Oi! Eu sou da Bia, do Colegio Estadual Barbosa Ferraz, na Rua Rio Grande do Sul, 1200.",
            "No Clube de Ciencias a gente faz projeto de compostagem, horta e captacao de agua da chuva. Quer saber?",
        ],
        choices: &["Conta do projeto!", "O que e coleta seletiva?", "Tchau"],
        next: &[8, 9, -1],
    },
    // 8
    Node {
        speaker: "Bia",
        lines: &[
            "A gente composita o que sobra da cantina e usa na horta escolar. O que era residuo virou salada.",
            " tambem captamos a chuva do telhado para irrigar. Todo ano a feira Parana Faz Ciencia leva o nosso projeto.",
        ],
        choices: &["Voltar"],
        next: &[7],
    },
    // 9
    Node {
        speaker: "Bia",
        lines: &[
            "E o ato de jogar cada tipo de material no lugar certo.",
            "No Vale do Ivai a cidade cresce em cima da producao de milho. So de波及 imagine quanta embalagem vem junto.",
        ],
        choices: &["Voltar"],
        next: &[7],
    },
    // 10 - Professora Sandra, raiz
    Node {
        speaker: "Professora Sandra (Barbosa Ferraz)",
        lines: &[
            "Oi! Eu sou a Sandra, professora do Barbosa Ferraz.",
            "A escola tem horta, compostagem e varias turmas no Clube de Ciencias. Vamos combinar?",
        ],
        choices: &["O que da para fazer na escola?", "Onde fica a horta?", "Tchau"],
        next: &[11, 12, -1],
    },
    // 11
    Node {
        speaker: "Professora Sandra",
        lines: &[
            "Cada sala pode ter uma cacamba de reciclaveis e uma de nao reciclaveis.",
            "E preciso medir: pesam a turma no comeco e no fim da semana. O que muda de peso mudou de atitude.",
        ],
        choices: &["Voltar"],
        next: &[10],
    },
    // 12
    Node {
        speaker: "Professora Sandra",
        lines: &[
            "Esta ali atras do portao, do lado da quadra. De manha e o lugar mais cheio de gente da escola.",
            "Voce tambem pode cuidar: regar, tirar o mato e separar o que cair no chao.",
        ],
        choices: &["Voltar"],
        next: &[10],
    },
    // 13 - Rui, raiz
    Node {
        speaker: "Rui (estagiario)",
        lines: &[
            "Ei! Cuidado com a quadra, ela e usada pela escola inteira.",
            "Eu ajudo na horta nos intervalos. Se quiser, da para pegar uma composira aqui.",
        ],
        choices: &["O que eu faco agora?", "Tchau"],
        next: &[14, -1],
    },
    // 14
    Node {
        speaker: "Rui",
        lines: &[
            "Clique no que esta no chao e depois na lixeira certa.",
            "Azul e reciclavel, verde e organico, vermelho e nao reciclavel. Errar nao acaba o jogo, mas custa pontos.",
        ],
        choices: &["Bora la!"],
        next: &[-1],
    },
];

/// Indice do no raiz de cada NPC (ordem igual a `world::NPC_NAMES`).
pub const NPC_ROOTS: [usize; 5] = [0, 4, 7, 10, 13];
