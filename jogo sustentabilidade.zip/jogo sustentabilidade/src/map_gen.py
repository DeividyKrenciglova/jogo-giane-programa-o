import json, math

LAT0, LON0 = -24.2533058, -51.6717374
S = 9.5
CX, CY = 640.0, 372.0
MPD_LAT = 110574.0
MPD_LON = 111320.0 * math.cos(math.radians(LAT0))

def proj(lat, lon):
    return (CX + (lon - LON0) * MPD_LON * S,
            CY - (lat - LAT0) * MPD_LAT * S)

def clip(line, pad=120):
    out = []
    for i in range(len(line) - 1):
        (x1, y1), (x2, y2) = line[i], line[i + 1]
        if max(x1, x2) < -pad or min(x1, x2) > 1280 + pad:
            continue
        if max(y1, y2) < -pad or min(y1, y2) > 720 + pad:
            continue
        out.append((round(x1, 1), round(y1, 1), round(x2, 1), round(y2, 1)))
    return out

d = json.load(open('praca.json'))
park = None
roads = {}
for e in d['elements']:
    t = e.get('tags') or {}
    g = e.get('geometry') or []
    if t.get('leisure') == 'park':
        park = [proj(p['lat'], p['lon']) for p in g]
    elif t.get('highway'):
        segs = clip([proj(p['lat'], p['lon']) for p in g])
        if segs:
            roads.setdefault(t.get('name') or 'rua sem nome', []).extend(segs)

fountain = proj(-24.2531089, -51.671704)

park_segs = []
for i in range(len(park) - 1):
    park_segs.append([round(park[i][0], 1), round(park[i][1], 1),
                      round(park[i + 1][0], 1), round(park[i + 1][1], 1)])

xs = [p[0] for p in park]
ys = [p[1] for p in park]
R = lambda v: round(v, 1)
print('PARQUE   x %.0f..%.0f  y %.0f..%.0f' % (min(xs), max(xs), min(ys), max(ys)))
print('         %.0f x %.0f px  (%.1f px/m)' % (max(xs)-min(xs), max(ys)-min(ys), S))
print('CHAFARIZ (%.1f, %.1f)' % (fountain[0], fountain[1]))
print('\nRUAS NA TELA:')
for n, segs in roads.items():
    print('  %-34s %3d trechos' % (n[:32], len(segs)))

out = {'fountain': [R(fountain[0]), R(fountain[1])],
       'park': park_segs,
       'roads': [[n, [[a, b, c, d] for a, b, c, d in segs]] for n, segs in roads.items()]}
json.dump(out, open('map.json', 'w'), ensure_ascii=False)
print('\nmap.json gerado')
