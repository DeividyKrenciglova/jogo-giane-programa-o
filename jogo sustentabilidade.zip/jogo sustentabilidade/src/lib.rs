//! Jogo de sustentabilidade - Ivaipora-PR.
//! Nucleo em Rust compilado para WebAssembly, sem nenhuma dependencia externa.
//!
//! O JavaScript fala com este modulo por funcoes `extern "C"` simples
//! (numeros) e por um buffer de texto (`text_ptr`/`text_len`).
//!
//! Nao ha vidas nem tempo limite: errar a lixeira apenas ensina, custando
//! pontos e a combinacao. O item volta para o chao onde foi solto.

mod dialogue;
mod text;
mod trash;
mod world;

use dialogue::NODES;
use text::set_out;
use trash::{BIN_COLORS, BIN_NAMES, TRASH};
use world::{Obj, K_BIN, K_EXIT, K_INFO, K_NPC, K_TRASH, NPC_NAMES, SCENE_NAMES};

pub const PHASE_TITLE: u32 = 0;
pub const PHASE_PLAY: u32 = 1;
pub const PHASE_TALK: u32 = 2;
pub const PHASE_END: u32 = 3;

pub const TONE_INFO: u32 = 0;
pub const TONE_OK: u32 = 1;
pub const TONE_BAD: u32 = 2;
pub const TONE_AI: u32 = 3;

/// Eventos devolvidos ao JavaScript.
pub const EV_NONE: u32 = 0;
pub const EV_BEGIN: u32 = 1;
pub const EV_CORRECT: u32 = 2;
pub const EV_WRONG: u32 = 3;
pub const EV_PICK: u32 = 4;
pub const EV_DROP: u32 = 5;
pub const EV_BIN_EMPTY: u32 = 6;
pub const EV_TALK: u32 = 7;
pub const EV_INFO: u32 = 8;
pub const EV_SCENE: u32 = 9;
pub const EV_FINISH: u32 = 10;

/// Abaixo deste deslocamento o toque e considerado "clique", nao arrasto.
const DRAG_MIN: f32 = 10.0;
/// Area clicavel de um item, maior que o desenho, para pegar com o dedo.
const PICK_PAD: f32 = 14.0;

/// Textos clicaveis que explicam cada lugar. O indice e o `variant` do `K_INFO`.
const INFOS: [&[(&str, &str)]; 2] = [
    &[
        (
            "Chafariz da Praça Espanha",
            "O chafariz fica no Largo Marechal Deodoro, centro de Ivaipora. E o ponto de encontro da cidade: as pessoas param aqui para conversar.",
        ),
        (
            "O parque, no mapa real",
            "A peca inteira foi desenhada em cima do contorno verdadeiro do parque, tirado do OpenStreetMap. As arvores, os bancos e o chafariz estao nas posicoes de la.",
        ),
        (
            "Lixo na praça",
            "Depois da feira e dos fins de semana sobra papelão, copo descartavel e bitus de cigarro. Separar antes da lixeira e o que muda o resultado.",
        ),
    ],
    &[
        (
            "Colégio Estadual Barbosa Ferraz",
            "Rua Rio Grande do Sul, 1200, no Centro. Atende cerca de mil alunos nos turnos matutino, vespertino e noturno, com Ensino Medio e cursos tecnicos.",
        ),
        (
            "Quadra",
            "Usada pelas turmas de educacao fisica e pelo grêmio estudantil. Vale a mesma regra do resto: o que cai no chao entra na cacamba certa.",
        ),
        (
            "Horta escolar",
            "A horta e alimentada pela compostagem do que sobra na cantina. O que era residuo vira salada, e e um dos projetos do Clube de Ciencias.",
        ),
    ],
];

struct Game {
    scene: usize,
    score: i32,
    streak: i32,
    best_streak: i32,
    elapsed: f32,
    phase: u32,
    ended: u32,
    held: i32,
    msg: String,
    tone: u32,
    msg_time: f32,
    facts: u32,
    correct: u32,
    wrong: u32,
    total: u32,
    talked: [bool; 5],
    ai_turns: u32,
    dlg: i32,
    scenes: Vec<world::SceneDef>,
}

impl Game {
    fn new() -> Game {
        let scenes = world::build();
        let total = scenes
            .iter()
            .flat_map(|s| s.objs.iter())
            .filter(|o| o.kind == K_TRASH)
            .count() as u32;
        Game {
            scene: 0,
            score: 0,
            streak: 0,
            best_streak: 0,
            elapsed: 0.0,
            phase: PHASE_TITLE,
            ended: 0,
            held: -1,
            msg: String::new(),
            tone: TONE_INFO,
            msg_time: 0.0,
            facts: 0,
            correct: 0,
            wrong: 0,
            total,
            talked: [false; 5],
            ai_turns: 0,
            dlg: -1,
            scenes,
        }
    }

    fn reset(&mut self) {
        let f = Game::new();
        *self = f;
        self.phase = PHASE_PLAY;
        for sc in self.scenes.iter_mut() {
            for o in sc.objs.iter_mut() {
                if o.kind == K_TRASH {
                    o.alive = true;
                }
            }
        }
    }

    fn objs(&self) -> &[Obj] {
        &self.scenes[self.scene].objs
    }

    fn objs_mut(&mut self) -> &mut [Obj] {
        &mut self.scenes[self.scene].objs
    }

    fn trash_left(&self) -> u32 {
        self.scenes
            .iter()
            .flat_map(|s| s.objs.iter())
            .filter(|o| o.kind == K_TRASH && o.alive)
            .count() as u32
    }

    fn say(&mut self, text: &str, tone: u32) {
        self.msg.clear();
        self.msg.push_str(text);
        self.tone = tone;
        self.msg_time = 6.0;
    }

    fn check_win(&mut self) {
        if self.ended == 0 && self.trash_left() == 0 {
            self.phase = PHASE_END;
            self.ended = 1;
            // Bônus: quanto menos erros, maior o prêmio final.
            let perfect = if self.wrong == 0 { 250 } else { 0 };
            self.score += perfect;
            self.msg.clear();
        }
    }

    /// Item de lixo sob o ponto, com área de tolerância maior que o desenho.
    fn pick_at(&self, x: f32, y: f32) -> i32 {
        for (i, o) in self.objs().iter().enumerate().rev() {
            if o.kind != K_TRASH || !o.alive {
                continue;
            }
            let cx = o.x + o.w / 2.0;
            let cy = o.y + o.h / 2.0;
            let hw = o.w / 2.0 + PICK_PAD;
            let hh = o.h / 2.0 + PICK_PAD;
            if (x - cx).abs() <= hw && (y - cy).abs() <= hh {
                return i as i32;
            }
        }
        -1
    }

    /// Objeto clicável mais a frente, na ordem em que e desenhado.
    fn hit(&self, x: f32, y: f32) -> i32 {
        for (i, o) in self.objs().iter().enumerate().rev() {
            if o.kind == K_TRASH && !o.alive {
                continue;
            }
            if x >= o.x && x <= o.x + o.w && y >= o.y && y <= o.y + o.h {
                return i as i32;
            }
        }
        -1
    }

    fn bin_at(&self, x: f32, y: f32) -> Option<usize> {
        for o in self.objs().iter() {
            if o.kind != K_BIN {
                continue;
            }
            let cx = o.x + o.w / 2.0;
            let cy = o.y + o.h / 2.0;
            if (x - cx).abs() <= o.w / 2.0 + 8.0 && (y - cy).abs() <= o.h / 2.0 + 8.0 {
                return Some(o.variant as usize);
            }
        }
        None
    }

    fn open_talk(&mut self, npc: usize) {
        self.dlg = dialogue::NPC_ROOTS[npc] as i32;
        self.talked[npc] = true;
        self.phase = PHASE_TALK;
    }

    fn apply_choice(&mut self, idx: usize) {
        let node = &NODES[self.dlg as usize];
        let mut next = -1;
        if let Some(n) = node.next.get(idx) {
            next = *n;
        }
        if next < 0 {
            self.dlg = -1;
            self.phase = PHASE_PLAY;
        } else {
            self.dlg = next;
        }
    }

    /// Solta o item da mao em (x, y), clampado na tela.
    fn drop_held(&mut self, x: f32, y: f32) {
        if self.held < 0 {
            return;
        }
        let h = self.held as usize;
        let (w, hgt) = {
            let o = self.objs()[h];
            (o.w, o.h)
        };
        let nx = (x - w / 2.0).clamp(20.0, world::W - w - 20.0);
        let ny = (y - hgt / 2.0).clamp(78.0, 648.0 - hgt);
        self.objs_mut()[h].x = nx;
        self.objs_mut()[h].y = ny;
        self.objs_mut()[h].alive = true;
        self.held = -1;
    }

    /// Avalia o item da mao contra a lixeira `bin`.
    fn deliver(&mut self, bin: usize) -> u32 {
        let h = self.held as usize;
        let variant = self.objs()[h].variant as usize;
        let t = &TRASH[variant];
        let right = t.bin.id() as usize;

        if right == bin {
            self.score += t.points + self.streak * 5;
            self.streak += 1;
            self.best_streak = self.best_streak.max(self.streak);
            self.correct += 1;
            self.facts += 1;
            self.objs_mut()[h].alive = false;
            self.held = -1;
            let text = format!("+{} pontos! {} {}", t.points, t.name, t.tip);
            self.say(&text, TONE_OK);
            self.check_win();
            if self.ended == 1 {
                EV_FINISH
            } else {
                EV_CORRECT
            }
        } else {
            // Sem punicao: apenas mostra onde o material deveria ir.
            self.wrong += 1;
            self.streak = 0;
            let where_ = BIN_NAMES[right];
            let tip = t.tip;
            let name = t.name;
            self.drop_held_near_current();
            let text = format!(
                "Quase! {} vai para a {} de {}. {}",
                name, where_, BIN_COLORS[right], tip
            );
            self.say(&text, TONE_BAD);
            EV_WRONG
        }
    }

    /// Devolve o item ao chao, no lugar em que estava antes de ser arrastado.
    fn drop_held_near_current(&mut self) {
        if self.held < 0 {
            return;
        }
        let h = self.held as usize;
        self.objs_mut()[h].alive = true;
        self.held = -1;
    }
}

static mut GAME: Option<Game> = None;

fn game() -> &'static mut Game {
    unsafe {
        let slot = &raw mut GAME;
        (*slot).get_or_insert_with(Game::new)
    }
}

// ---------------------------------------------------------------- ciclo de vida

#[no_mangle]
pub extern "C" fn start() {
    let g = game();
    g.reset();
}

#[no_mangle]
pub extern "C" fn tick(dt: f32) {
    let g = game();
    if g.phase != PHASE_PLAY {
        return;
    }
    g.elapsed += dt;
    if g.msg_time > 0.0 {
        g.msg_time -= dt;
        if g.msg_time <= 0.0 {
            g.msg.clear();
        }
    }
}

// ------------------------------------------------------------------- entrada

/// O jogador comecou a arrastar. `x, y` em pixels da tela.
#[no_mangle]
pub extern "C" fn pointer_down(x: f32, y: f32) -> u32 {
    let g = game();
    match g.phase {
        PHASE_TITLE => {
            g.reset();
            return EV_BEGIN;
        }
        PHASE_END => {
            g.reset();
            return EV_BEGIN;
        }
        PHASE_TALK => return EV_NONE,
        _ => {}
    }

    // Se ja estava com um item na mao, um novo toque em lixeira solta ele.
    if g.held >= 0 {
        if let Some(bin) = g.bin_at(x, y) {
            return g.deliver(bin);
        }
    }

    match g.pick_at(x, y) {
        i if i >= 0 => {
            g.objs_mut()[i as usize].alive = false;
            g.held = i;
            g.picked_this_press = true;
            EV_PICK
        }
        _ => {
            let name = if g.held >= 0 {
                let h = g.held as usize;
                let v = g.objs()[h].variant as usize;
                Some(TRASH[v].name)
            } else {
                None
            };
            match name {
                Some(n) => {
                    let t = format!("Pegando: {}. Arraste até a lixeira certa.", n);
                    g.say(&t, TONE_INFO);
                }
                None => return EV_NONE,
            }
            EV_PICK
        }
    }
}

/// O jogador soltou. `moved` e o deslocamento em pixels desde o toque.
#[no_mangle]
pub extern "C" fn pointer_up(x: f32, y: f32, moved: f32) -> u32 {
    let g = game();
    if g.phase == PHASE_TITLE {
        g.reset();
        return EV_BEGIN;
    }
    if g.phase == PHASE_END {
        g.reset();
        return EV_BEGIN;
    }
    if g.phase == PHASE_TALK {
        return EV_NONE;
    }

    if g.held >= 0 {
        // Soltar em cima de uma lixeira entrega o item.
        if let Some(bin) = g.bin_at(x, y) {
            g.picked_this_press = false;
            return g.deliver(bin);
        }

        if moved >= DRAG_MIN {
            // Arrasto de verdade: o item fica onde foi largado.
            let name = {
                let h = g.held as usize;
                let v = g.objs()[h].variant as usize;
                TRASH[v].name
            };
            g.picked_this_press = false;
            g.drop_held(x, y);
            let text = format!("Você deixou {} aí. Arraste-o até a lixeira.", name);
            g.say(&text, TONE_INFO);
            return EV_DROP;
        }

        if g.picked_this_press {
            // Toque curto no item: ele gruda na mao, para arrastar depois.
            g.picked_this_press = false;
            return EV_PICK;
        }

        // Ja estava com um item na mao e tocou em outra coisa:
        // devolve o item e processa o toque como clique normal.
        let name = {
            let h = g.held as usize;
            let v = g.objs()[h].variant as usize;
            TRASH[v].name
        };
        g.picked_this_press = false;
        g.drop_held_near_current();
        let text = format!("Você devolveu {} ao chão.", name);
        g.say(&text, TONE_INFO);
    } else {
        g.picked_this_press = false;
    }

    // Nada na mao (ou item ja devolvido): e um clique comum, que abre
    // conversas, placas e a saida para o colégio.
    click(x, y)
}

/// Clique sem arrastar: conversar, ler placas, trocar de cena.
#[no_mangle]
pub extern "C" fn click(x: f32, y: f32) -> u32 {
    let g = game();
    match g.phase {
        PHASE_TITLE => {
            g.reset();
            return EV_BEGIN;
        }
        PHASE_END => {
            g.reset();
            return EV_BEGIN;
        }
        PHASE_TALK => return EV_NONE,
        _ => {}
    }

    let mut devolveu = false;
    if g.held >= 0 {
        if let Some(bin) = g.bin_at(x, y) {
            g.picked_this_press = false;
            return g.deliver(bin);
        }
        // Com algo na mao, qualquer outro clique devolve o item ao chao e
        // segue executando a acao (conversar, ler placa, trocar de cena).
        if g.pick_at(x, y) < 0 {
            let h = g.held as usize;
            let v = g.objs()[h].variant as usize;
            let name = TRASH[v].name;
            g.drop_held_near_current();
            let text = format!("Você devolveu {} para o chão.", name);
            g.say(&text, TONE_INFO);
            devolveu = true;
        }
    }
    g.picked_this_press = false;

    let idx = g.hit(x, y);
    if idx < 0 {
        return if devolveu { EV_DROP } else { EV_NONE };
    }
    let kind = g.objs()[idx as usize].kind;
    let variant = g.objs()[idx as usize].variant as usize;

    match kind {
        K_BIN => {
            let label = BIN_NAMES[variant];
            let color = BIN_COLORS[variant];
            let text = format!("Lixeira {} (cor {}). Arraste um item até ela.", label, color);
            g.say(&text, TONE_INFO);
            EV_BIN_EMPTY
        }
        K_NPC => {
            g.open_talk(variant);
            EV_TALK
        }
        K_INFO => {
            let list = &INFOS[g.scene];
            let (title, body) = list.get(variant).copied().unwrap_or(("", ""));
            g.say(&format!("{}: {}", title, body), TONE_INFO);
            EV_INFO
        }
        K_EXIT => {
            if g.held >= 0 {
                g.drop_held_near_current();
            }
            g.scene = if g.scene == 0 { 1 } else { 0 };
            g.say(&format!("Você foi para: {}.", SCENE_NAMES[g.scene]), TONE_INFO);
            EV_SCENE
        }
        K_TRASH => {
            let v = g.objs()[idx as usize].variant as usize;
            let name = TRASH[v].name;
            let text = format!("{} — clique e arraste até a lixeira.", name);
            g.say(&text, TONE_INFO);
            EV_PICK
        }
        _ => EV_NONE,
    }
}

#[no_mangle]
pub extern "C" fn choose(idx: u32) -> u32 {
    let g = game();
    if g.phase != PHASE_TALK {
        return EV_NONE;
    }
    let n = NODES[g.dlg as usize].choices.len() as u32;
    if idx < n {
        g.apply_choice(idx as usize);
    }
    EV_NONE
}

#[no_mangle]
pub extern "C" fn ai_used() {
    let g = game();
    g.ai_turns += 1;
    g.facts += 1;
}

// --------------------------------------------------------------- consultas

macro_rules! num_getter {
    ($name:ident, $field:ident) => {
        #[no_mangle]
        pub extern "C" fn $name() -> f64 {
            game().$field as f64
        }
    };
}

num_getter!(phase, phase);
num_getter!(scene, scene);
num_getter!(score, score);
num_getter!(streak, streak);
num_getter!(best_streak, best_streak);
num_getter!(elapsed, elapsed);
num_getter!(held, held);
num_getter!(msg_tone, tone);
num_getter!(ended, ended);
num_getter!(facts, facts);
num_getter!(correct, correct);
num_getter!(wrong, wrong);
num_getter!(total, total);
num_getter!(ai_turns, ai_turns);
num_getter!(dlg_node, dlg);

#[no_mangle]
pub extern "C" fn trash_left() -> f64 {
    game().trash_left() as f64
}

#[no_mangle]
pub extern "C" fn is_talked(i: u32) -> f64 {
    game().talked.get(i as usize).copied().unwrap_or(false) as u8 as f64
}

#[no_mangle]
pub extern "C" fn obj_count() -> f64 {
    game().objs().len() as f64
}

#[no_mangle]
pub extern "C" fn obj_field(i: u32, field: u32) -> f64 {
    let objs = game().objs();
    let o = match objs.get(i as usize) {
        Some(o) => o,
        None => return 0.0,
    };
    match field {
        0 => o.kind as f64,
        1 => o.variant as f64,
        2 => o.x as f64,
        3 => o.y as f64,
        4 => o.w as f64,
        5 => o.h as f64,
        6 => o.alive as u8 as f64,
        _ => 0.0,
    }
}

// ------------------------------------------------------------------- textos

#[no_mangle]
pub extern "C" fn text_msg() {
    let g = game();
    let s = if g.msg.is_empty() {
        match g.phase {
            PHASE_TITLE => "Clique ou toque para começar",
            PHASE_END => {
                if g.ended == 1 {
                    "Clique ou toque para jogar de novo"
                } else {
                    "Clique ou toque para tentar de novo"
                }
            }
            _ => "",
        }
    } else {
        &g.msg
    };
    set_out(s);
}

#[no_mangle]
pub extern "C" fn text_scene_title() {
    set_out(SCENE_NAMES[game().scene]);
}

#[no_mangle]
pub extern "C" fn text_scene_sub() {
    set_out(game().scenes[game().scene].subtitle);
}

#[no_mangle]
pub extern "C" fn text_obj_label(i: u32) {
    let g = game();
    let objs = g.objs();
    let o = match objs.get(i as usize) {
        Some(o) => o,
        None => return,
    };
    let s = match o.kind {
        K_TRASH => TRASH[o.variant as usize].name,
        K_BIN => BIN_NAMES[o.variant as usize],
        K_NPC => NPC_NAMES[o.variant as usize],
        K_EXIT => {
            if g.scene == 0 {
                "Ir ao Colégio"
            } else {
                "Voltar à praça"
            }
        }
        K_INFO => INFOS[g.scene].get(o.variant as usize).map(|p| p.0).unwrap_or(""),
        _ => "",
    };
    set_out(s);
}

#[no_mangle]
pub extern "C" fn text_trash_name(v: u32) {
    set_out(TRASH.get(v as usize).map(|t| t.name).unwrap_or(""));
}

#[no_mangle]
pub extern "C" fn text_trash_tip(v: u32) {
    set_out(TRASH.get(v as usize).map(|t| t.tip).unwrap_or(""));
}

#[no_mangle]
pub extern "C" fn text_trash_body(v: u32) {
    set_out(TRASH.get(v as usize).map(|t| t.body).unwrap_or("#fff"));
}

#[no_mangle]
pub extern "C" fn text_trash_cap(v: u32) {
    set_out(TRASH.get(v as usize).map(|t| t.cap).unwrap_or("#fff"));
}

#[no_mangle]
pub extern "C" fn text_bin_name(v: u32) {
    set_out(BIN_NAMES.get(v as usize).copied().unwrap_or(""));
}

#[no_mangle]
pub extern "C" fn text_bin_color(v: u32) {
    set_out(BIN_COLORS.get(v as usize).copied().unwrap_or("#fff"));
}

#[no_mangle]
pub extern "C" fn text_npc_name(v: u32) {
    set_out(NPC_NAMES.get(v as usize).copied().unwrap_or(""));
}

#[no_mangle]
pub extern "C" fn text_dlg_speaker() {
    let g = game();
    if g.phase != PHASE_TALK || g.dlg < 0 {
        set_out("");
        return;
    }
    set_out(NODES[g.dlg as usize].speaker);
}

#[no_mangle]
pub extern "C" fn text_dlg_line(i: u32) {
    let g = game();
    if g.phase != PHASE_TALK || g.dlg < 0 {
        set_out("");
        return;
    }
    set_out(NODES[g.dlg as usize].lines.get(i as usize).copied().unwrap_or(""));
}

#[no_mangle]
pub extern "C" fn dlg_lines() -> f64 {
    let g = game();
    if g.phase != PHASE_TALK || g.dlg < 0 {
        return 0.0;
    }
    NODES[g.dlg as usize].lines.len() as f64
}

#[no_mangle]
pub extern "C" fn dlg_choices() -> f64 {
    let g = game();
    if g.phase != PHASE_TALK || g.dlg < 0 {
        return 0.0;
    }
    NODES[g.dlg as usize].choices.len() as f64
}

#[no_mangle]
pub extern "C" fn text_dlg_choice(i: u32) {
    let g = game();
    if g.phase != PHASE_TALK || g.dlg < 0 {
        set_out("");
        return;
    }
    set_out(NODES[g.dlg as usize].choices.get(i as usize).copied().unwrap_or(""));
}

#[no_mangle]
pub extern "C" fn held_bin() -> f64 {
    let g = game();
    if g.held < 0 {
        return -1.0;
    }
    let h = g.held as usize;
    let v = g.objs()[h].variant as usize;
    TRASH[v].bin.id() as f64
}

#[no_mangle]
pub extern "C" fn held_variant() -> f64 {
    let g = game();
    if g.held < 0 {
        return -1.0;
    }
    let h = g.held as usize;
    g.objs()[h].variant as f64
}
