//! Tipos de lixo, lixeiras e o material educativo de cada item.

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Bin {
    Reciclavel,
    Organico,
    NaoReciclavel,
}

impl Bin {
    pub fn id(self) -> u32 {
        match self {
            Bin::Reciclavel => 0,
            Bin::Organico => 1,
            Bin::NaoReciclavel => 2,
        }
    }
}

pub const BIN_NAMES: [&str; 3] = ["Recicláveis", "Orgânicos", "Não recicláveis"];
pub const BIN_COLORS: [&str; 3] = ["#2f7dd1", "#3f9b46", "#d2452f"];

pub struct TrashKind {
    pub name: &'static str,
    pub bin: Bin,
    pub points: i32,
    pub body: &'static str,
    pub cap: &'static str,
    pub tip: &'static str,
}

pub const TRASH: &[TrashKind] = &[
    TrashKind {
        name: "Garrafa PET",
        bin: Bin::Reciclavel,
        points: 10,
        body: "#7fd4e8",
        cap: "#2b8fb0",
        tip: "Uma garrafa PET leva até 400 anos para se decompor na natureza.",
    },
    TrashKind {
        name: "Lata de alumínio",
        bin: Bin::Reciclavel,
        points: 10,
        body: "#c9d2dc",
        cap: "#8a97a6",
        tip: "Reciclar uma lata gasta só 5% da energia de produzir uma nova.",
    },
    TrashKind {
        name: "Papelão",
        bin: Bin::Reciclavel,
        points: 10,
        body: "#c99a5b",
        cap: "#96682f",
        tip: "Uma árvore adulta produz cerca de 4 kg de papel por ano.",
    },
    TrashKind {
        name: "Copo de vidro",
        bin: Bin::Reciclavel,
        points: 10,
        body: "#9fd6c4",
        cap: "#5fa892",
        tip: "O vidro é 100% reciclável e não perde qualidade ao ser reciclado.",
    },
    TrashKind {
        name: "Garrafa de vidro",
        bin: Bin::Reciclavel,
        points: 10,
        body: "#8fc98f",
        cap: "#4f8f52",
        tip: "Vidros devem ir para a recicláveis mesmo quando estão quebrados.",
    },
    TrashKind {
        name: "Casca de banana",
        bin: Bin::Organico,
        points: 8,
        body: "#f2d14c",
        cap: "#a8871d",
        tip: "Resto de comida vira adubo. Ainda se joga fora muita comida no Brasil.",
    },
    TrashKind {
        name: "Pão amanhecido",
        bin: Bin::Organico,
        points: 8,
        body: "#e0a86a",
        cap: "#9c6a35",
        tip: "Pão amanhecido ainda é comida: doar evita desperdício de alimentos.",
    },
    TrashKind {
        name: "Folha seca",
        bin: Bin::Organico,
        points: 8,
        body: "#b78a3e",
        cap: "#7a5a20",
        tip: "Folhas e galhos podem virar adubo e reduzir a queima de lixo.",
    },
    TrashKind {
        name: "Copo descartável",
        bin: Bin::NaoReciclavel,
        points: 6,
        body: "#f0f2f5",
        cap: "#c3cad3",
        tip: "Copo descartável não é reciclado: vai para o lixo comum e suja o rio.",
    },
    TrashKind {
        name: "Embalagem de isopor",
        bin: Bin::NaoReciclavel,
        points: 6,
        body: "#f5f0dc",
        cap: "#cfc6a6",
        tip: "Isopor não recicla e polui por séculos. O ideal é não usar.",
    },
    TrashKind {
        name: "Isca de chiclete",
        bin: Bin::NaoReciclavel,
        points: 6,
        body: "#e08fa0",
        cap: "#a85565",
        tip: "Cada chiclete leva cerca de 5 anos no solo e ninguém pisa para recolher.",
    },
    TrashKind {
        name: "Bitu de cigarro",
        bin: Bin::NaoReciclavel,
        points: 6,
        body: "#d8d2c4",
        cap: "#9a9280",
        tip: "Bitus de cigarro chegam aos rios. Todo quilo de lixo tem cerca de 8% deles.",
    },
];
