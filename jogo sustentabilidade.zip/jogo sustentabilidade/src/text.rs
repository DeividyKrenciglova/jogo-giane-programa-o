//! Ponte de strings Rust -> JS sem wasm-bindgen.
//!
//! O JavaScript escreve os caracteres em um buffer unico: toda funcao de leitura
//! de texto chama `set_out` antes e o JS le `text_ptr()` / `text_len()`.

const OUT_CAP: usize = 1 << 16;

static mut OUT: [u8; OUT_CAP] = [0; OUT_CAP];
static mut OUT_LEN: usize = 0;

pub fn set_out(s: &str) {
    unsafe {
        let n = s.len().min(OUT_CAP - 1);
        let buf = &raw mut OUT;
        let src = s.as_bytes();
        core::ptr::copy_nonoverlapping(src.as_ptr(), (*buf).as_mut_ptr(), n);
        let len = &raw mut OUT_LEN;
        *len = n;
    }
}

#[no_mangle]
pub extern "C" fn text_ptr() -> *const u8 {
    unsafe { (*(&raw const OUT)).as_ptr() }
}

#[no_mangle]
pub extern "C" fn text_len() -> usize {
    unsafe { *(&raw const OUT_LEN) }
}
