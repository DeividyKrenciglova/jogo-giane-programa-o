//! Layout das duas cenas, em coordenadas de tela de 1280x720.
//!
//! As posicoes sao dadas pelo CENTRO do objeto. A cena da praca e vista de
//! cima e respeita o contorno real do parque (Largo Marechal Deodoro); os
//! lugares foram conferidos por `src/map_gen.py` para:
//!   - caberem entre o HUD superior e a faixa de mensagem,
//!   - caírem dentro do poligono do parque,
//!   - nao se sobreporem (as arvores podem encostar no resto).
//!
//! Faixas da tela: HUD 0..64, area jogavel 64..604, mensagem ate 664.

pub const W: f32 = 1280.0;
pub const H: f32 = 720.0;

#[no_mangle]
pub extern "C" fn world_w() -> f64 {
    W as f64
}

#[no_mangle]
pub extern "C" fn world_h() -> f64 {
    H as f64
}

pub const K_DECO: u32 = 1;
pub const K_TRASH: u32 = 2;
pub const K_BIN: u32 = 3;
pub const K_NPC: u32 = 4;
pub const K_INFO: u32 = 5;
pub const K_EXIT: u32 = 6;

pub const NPC_NAMES: [&str; 5] = [
    "Dona Marta",
    "Seu Antônio",
    "Bia",
    "Professora Sandra",
    "Rui",
];

pub const SCENE_NAMES: [&str; 2] = ["Praça Espanha", "Col. Barbosa Ferraz"];
pub const SCENE_SUBS: [&str; 2] = [
    "Largo Marechal Deodoro - Centro",
    "Rua Rio Grande do Sul, 1200 - Centro",
];

/// Tamanho da area clicavel de cada tipo de objeto.
const S_TREE: f32 = 76.0;
const S_BENCH: f32 = 62.0;
const S_BIN: f32 = 62.0;
const S_NPC: f32 = 48.0;
const S_TRASH: f32 = 56.0;

#[derive(Clone, Copy)]
pub struct Obj {
    pub kind: u32,
    pub variant: u32,
    pub x: f32,
    pub y: f32,
    pub w: f32,
    pub h: f32,
    pub alive: bool,
}

pub struct SceneDef {
    pub subtitle: &'static str,
    pub objs: Vec<Obj>,
}

/// Objeto quadrado, com (cx, cy) no centro.
fn sq(kind: u32, variant: u32, cx: f32, cy: f32, size: f32) -> Obj {
    Obj {
        kind,
        variant,
        x: cx - size / 2.0,
        y: cy - size / 2.0,
        w: size,
        h: size,
        alive: true,
    }
}

fn tree(cx: f32, cy: f32) -> Obj {
    sq(K_DECO, 0, cx, cy, S_TREE)
}
fn bench(cx: f32, cy: f32) -> Obj {
    sq(K_DECO, 1, cx, cy, S_BENCH)
}
fn bin(variant: u32, cx: f32, cy: f32) -> Obj {
    sq(K_BIN, variant, cx, cy, S_BIN)
}
fn npc(variant: u32, cx: f32, cy: f32) -> Obj {
    sq(K_NPC, variant, cx, cy, S_NPC)
}
fn trash(variant: u32, cx: f32, cy: f32) -> Obj {
    sq(K_TRASH, variant, cx, cy, S_TRASH)
}

/// Retangulo com (cx, cy) no centro, para informacoes e placas.
fn rect(kind: u32, variant: u32, cx: f32, cy: f32, w: f32, h: f32) -> Obj {
    Obj {
        kind,
        variant,
        x: cx - w / 2.0,
        y: cy - h / 2.0,
        w,
        h,
        alive: true,
    }
}

pub fn build() -> Vec<SceneDef> {
    // --------------------------------- Praca Espanha (Largo Marechal Deodoro)
    let praca = SceneDef {
        subtitle: SCENE_SUBS[0],
        objs: vec![
            // chafariz, na posicao real do OSM (amenity=fountain)
            rect(K_INFO, 0, 672.0, 165.0, 110.0, 110.0),
            // bancos em anel ao redor do chafariz
            bench(574.0, 132.0),
            bench(772.0, 118.0),
            bench(600.0, 214.0),
            // arvores (a praca e conhecida pelas arvores grandes)
            tree(668.0, 434.0),
            tree(539.0, 188.0),
            tree(617.0, 327.0),
            tree(777.0, 435.0),
            tree(880.0, 284.0),
            tree(507.0, 446.0),
            tree(763.0, 329.0),
            tree(463.0, 354.0),
            tree(843.0, 506.0),
            // lixeiras, na entrada sul
            bin(0, 560.0, 505.0),
            bin(1, 660.0, 505.0),
            bin(2, 760.0, 505.0),
            // moradores
            npc(0, 471.0, 292.0),
            npc(1, 731.0, 561.0),
            npc(2, 843.0, 234.0),
            // placa de saida, na calcada em frente ao parque
            rect(K_EXIT, 1, 950.0, 566.0, 128.0, 44.0),
            // lixo espalhado pela praca
            trash(0, 533.0, 340.0),
            trash(1, 833.0, 174.0),
            trash(2, 696.0, 384.0),
            trash(3, 584.0, 429.0),
            trash(8, 807.0, 387.0),
            trash(5, 821.0, 290.0),
            trash(6, 494.0, 223.0),
            trash(10, 902.0, 357.0),
            trash(9, 890.0, 460.0),
            trash(7, 600.0, 272.0),
        ],
    };

    // --------------------------- Colegio Estadual Barbosa Ferraz
    let colegio = SceneDef {
        subtitle: SCENE_SUBS[1],
        objs: vec![
            // predio da escola
            rect(K_INFO, 0, 640.0, 136.0, 620.0, 92.0),
            // quadra
            rect(K_INFO, 1, 1024.0, 313.0, 296.0, 190.0),
            // horta escolar
            rect(K_INFO, 2, 175.0, 316.0, 170.0, 180.0),
            // arvores do patio
            tree(200.0, 150.0),
            tree(1080.0, 150.0),
            tree(150.0, 470.0),
            tree(1180.0, 470.0),
            // bancos
            bench(350.0, 300.0),
            bench(700.0, 300.0),
            // lixeiras da escola
            bin(0, 520.0, 500.0),
            bin(1, 620.0, 500.0),
            bin(2, 720.0, 500.0),
            // professora e estagiario
            npc(3, 640.0, 300.0),
            npc(4, 1010.0, 480.0),
            // placa de volta para a praca
            rect(K_EXIT, 0, 900.0, 566.0, 128.0, 44.0),
            // lixo no patio
            trash(2, 300.0, 232.0),
            trash(0, 430.0, 232.0),
            trash(1, 560.0, 232.0),
            trash(3, 690.0, 232.0),
            trash(4, 820.0, 232.0),
            trash(5, 950.0, 232.0),
            trash(6, 1080.0, 232.0),
            trash(7, 250.0, 412.0),
            trash(8, 380.0, 412.0),
            trash(9, 510.0, 412.0),
            trash(10, 640.0, 412.0),
            trash(11, 770.0, 412.0),
            trash(2, 900.0, 412.0),
            trash(0, 1030.0, 412.0),
            trash(6, 1160.0, 412.0),
        ],
    };

    vec![praca, colegio]
}
