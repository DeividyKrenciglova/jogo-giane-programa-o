// Desenho do cenario.
//
// A cena da praca e montada em cima do contorno real do parque e das ruas
// oficiais do OpenStreetMap (ver mapdata.js). A cena do colegio e um
// desenho proprio, no mesmo estilo de vista de cima.

import { MAP } from './mapdata.js';
import { mulberry } from './art.js';

const TAU = Math.PI * 2;

// -------------------------------------------------------------------- praca

export function drawPraca(ctx, t) {
  // base: terra batida em volta do parque
  ctx.fillStyle = '#c9c3b4';
  ctx.fillRect(0, 0, 1280, 720);

  grassBase(ctx);

  // ruas reais, desenhadas como faixas de asfalto
  for (const road of MAP.roads) {
    street(ctx, road.segs, road.name);
  }

  // parque: contorno real
  parkFill(ctx);

  // calcada interna + caminho ate o chafariz
  walk(ctx);

  // canteiros de flor nas bordas
  flowerBeds(ctx, t);

  // chafariz na posicao real
  fountain(ctx, MAP.fountain[0], MAP.fountain[1], t);
}

function grassBase(ctx) {
  const g = ctx.createLinearGradient(0, 0, 0, 720);
  g.addColorStop(0, '#9fbf7a');
  g.addColorStop(1, '#8aab68');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 1280, 720);
  // textura de grama
  const r = mulberry(5);
  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  ctx.lineWidth = 2;
  for (let i = 0; i < 900; i++) {
    const x = r() * 1280;
    const y = r() * 720;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + (r() - 0.5) * 6, y - 4 - r() * 5);
    ctx.stroke();
  }
}

function street(ctx, segs, name) {
  if (!segs.length) return;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  // calcada (faixa larga, por baixo)
  ctx.strokeStyle = 'rgba(60,54,44,0.15)';
  ctx.lineWidth = 62;
  strokeSegs(ctx, segs, 3, 4);
  ctx.strokeStyle = '#bdb8ac';
  ctx.lineWidth = 62;
  strokeSegs(ctx, segs);
  // meio-fio interno
  ctx.strokeStyle = 'rgba(120,112,96,0.45)';
  ctx.lineWidth = 54;
  strokeSegs(ctx, segs);
  // asfalto
  ctx.strokeStyle = '#6f7176';
  ctx.lineWidth = 50;
  strokeSegs(ctx, segs);
  // faixa central
  ctx.strokeStyle = 'rgba(240,226,150,0.75)';
  ctx.lineWidth = 3;
  ctx.setLineDash([18, 16]);
  strokeSegs(ctx, segs);
  ctx.setLineDash([]);

  // nome da rua uma vez, no primeiro trecho visivel
  const s = segs[0];
  const mx = (s[0] + s[2]) / 2;
  const my = (s[1] + s[3]) / 2;
  ctx.save();
  ctx.translate(mx, my);
  const ang = Math.atan2(s[3] - s[1], s[2] - s[0]);
  ctx.rotate(Math.abs(ang) > Math.PI / 2 ? ang + Math.PI : ang);
  ctx.font = '600 11px system-ui, sans-serif';
  ctx.textAlign = 'center';
  const w = ctx.measureText(name).width;
  ctx.fillStyle = 'rgba(240,238,228,0.85)';
  ctx.fillRect(-w / 2 - 5, -9, w + 10, 14);
  ctx.fillStyle = '#5d6166';
  ctx.fillText(name, 0, 2);
  ctx.restore();
}

function strokeSegs(ctx, segs, ox = 0, oy = 0) {
  ctx.beginPath();
  for (const [x1, y1, x2, y2] of segs) {
    ctx.moveTo(x1 + ox, y1 + oy);
    ctx.lineTo(x2 + ox, y2 + oy);
  }
  ctx.stroke();
}

function parkFill(ctx) {
  const path = new Path2D();
  MAP.park.forEach(([x1, y1, x2, y2], i) => {
    if (i === 0) path.moveTo(x1, y1);
    path.lineTo(x2, y2);
  });
  path.closePath();

  ctx.save();
  ctx.shadowColor = 'rgba(30,44,26,0.28)';
  ctx.shadowBlur = 16;
  ctx.shadowOffsetY = 4;
  ctx.fillStyle = '#6fa24f';
  ctx.fill(path);
  ctx.restore();

  // grama mais clara dentro
  const g = ctx.createRadialGradient(700, 330, 40, 700, 330, 420);
  g.addColorStop(0, '#8ec36a');
  g.addColorStop(1, '#6c9c4c');
  ctx.fillStyle = g;
  ctx.fill(path);

  // contorno
  ctx.strokeStyle = 'rgba(255,255,255,0.35)';
  ctx.lineWidth = 2.5;
  ctx.stroke(path);
}

function walk(ctx) {
  // trilha principal da entrada sul ate o chafariz
  const [fx, fy] = MAP.fountain;
  ctx.save();
  ctx.lineCap = 'round';
  ctx.strokeStyle = '#d8d2c2';
  ctx.lineWidth = 34;
  ctx.beginPath();
  ctx.moveTo(660, 630);
  ctx.bezierCurveTo(600, 520, 700, 380, fx, fy);
  ctx.stroke();
  ctx.strokeStyle = 'rgba(190,182,164,0.7)';
  ctx.lineWidth = 26;
  ctx.beginPath();
  ctx.moveTo(660, 630);
  ctx.bezierCurveTo(600, 520, 700, 380, fx, fy);
  ctx.stroke();
  // trilha transversal
  ctx.strokeStyle = '#d3ccbb';
  ctx.lineWidth = 24;
  ctx.beginPath();
  ctx.moveTo(460, 330);
  ctx.bezierCurveTo(580, 300, 760, 300, 900, 350);
  ctx.stroke();
  ctx.restore();
}

function flowerBeds(ctx, t) {
  const beds = [
    { x: 470, y: 200, r: 34 },
    { x: 890, y: 250, r: 30 },
    { x: 520, y: 470, r: 28 },
  ];
  const r = mulberry(19);
  for (const b of beds) {
    ctx.fillStyle = '#7a5f3c';
    ctx.beginPath();
    ctx.ellipse(b.x, b.y, b.r, b.r * 0.8, 0, 0, TAU);
    ctx.fill();
    for (let i = 0; i < 22; i++) {
      const a = r() * TAU;
      const d = r() * b.r;
      const sway = Math.sin(t * 1.4 + i) * 1.4;
      ctx.fillStyle = ['#f2d14c', '#e8734c', '#e9a0c8', '#fff0a0'][i % 4];
      ctx.beginPath();
      ctx.arc(b.x + Math.cos(a) * d + sway, b.y + Math.sin(a) * d * 0.8, 3.4, 0, TAU);
      ctx.fill();
    }
  }
}

function fountain(ctx, cx, cy, t) {
  ctx.save();
  ctx.translate(cx, cy);
  // sombra
  ctx.fillStyle = 'rgba(30,44,26,0.3)';
  ctx.beginPath();
  ctx.ellipse(4, 6, 58, 52, 0, 0, TAU);
  ctx.fill();
  // aro de pedra
  const rim = ctx.createLinearGradient(-56, -56, 56, 56);
  rim.addColorStop(0, '#e2dccc');
  rim.addColorStop(1, '#a9a294');
  ctx.fillStyle = rim;
  ctx.beginPath();
  ctx.arc(0, 0, 56, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = '#8e8878';
  ctx.lineWidth = 3;
  ctx.stroke();
  // agua
  const water = ctx.createRadialGradient(-14, -16, 6, 0, 0, 48);
  water.addColorStop(0, '#9fdcef');
  water.addColorStop(1, '#3d93bd');
  ctx.fillStyle = water;
  ctx.beginPath();
  ctx.arc(0, 0, 46, 0, TAU);
  ctx.fill();

  // jato, visto de cima: aneis concentricos pulsando
  for (let i = 0; i < 4; i++) {
    const p = ((t * 0.55 + i / 4) % 1);
    ctx.globalAlpha = 0.85 * (1 - p);
    ctx.strokeStyle = '#e8f8ff';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(0, 0, 6 + p * 38, 0, TAU);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  // goticulas
  const r = mulberry(41);
  for (let i = 0; i < 14; i++) {
    const a = r() * TAU + t * 0.7;
    const d = 10 + (r() * 0.5 + ((t * 0.35 + r()) % 1)) * 34;
    ctx.fillStyle = 'rgba(240,252,255,0.9)';
    ctx.beginPath();
    ctx.arc(Math.cos(a) * d, Math.sin(a) * d, 2.2, 0, TAU);
    ctx.fill();
  }
  // haste central
  ctx.fillStyle = '#d6cfbe';
  ctx.beginPath();
  ctx.arc(0, 0, 11, 0, TAU);
  ctx.fill();
  ctx.fillStyle = '#b3ab99';
  ctx.beginPath();
  ctx.arc(0, 0, 5, 0, TAU);
  ctx.fill();
  ctx.restore();
}

// ------------------------------------------------------------------ colegio

export function drawEscola(ctx) {
  ctx.fillStyle = '#a8bf80';
  ctx.fillRect(0, 0, 1280, 720);
  const r = mulberry(9);
  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  ctx.lineWidth = 2;
  for (let i = 0; i < 700; i++) {
    const x = r() * 1280;
    const y = r() * 720;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + (r() - 0.5) * 6, y - 4 - r() * 5);
    ctx.stroke();
  }

  // rua ao pe do terreno
  ctx.fillStyle = '#6f7176';
  ctx.fillRect(0, 640, 1280, 80);
  ctx.strokeStyle = 'rgba(240,226,150,0.7)';
  ctx.lineWidth = 3;
  ctx.setLineDash([18, 16]);
  ctx.beginPath();
  ctx.moveTo(0, 680);
  ctx.lineTo(1280, 680);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.font = '600 11px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(240,238,228,0.85)';
  ctx.fillRect(80, 693, 190, 15);
  ctx.fillStyle = '#5d6166';
  ctx.fillText('Rua Rio Grande do Sul', 175, 704);
  ctx.textAlign = 'left';

  // predio da escola, visto de cima
  schoolBuilding(ctx, 330, 96, 620, 96);

  // patio de terra batida
  ctx.fillStyle = '#cbbfa6';
  ctx.beginPath();
  ctx.roundRect(280, 216, 700, 400, 26);
  ctx.fill();
  ctx.strokeStyle = 'rgba(140,126,100,0.5)';
  ctx.lineWidth = 2;
  ctx.stroke();

  court(ctx, 852, 250, 300, 190);
  garden(ctx, 96, 250, 190, 180);
}

function schoolBuilding(ctx, x, y, w, h) {
  ctx.fillStyle = 'rgba(30,44,26,0.3)';
  ctx.beginPath();
  ctx.roundRect(x + 5, y + 7, w, h, 8);
  ctx.fill();
  // telhado
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, '#b3584a');
  g.addColorStop(1, '#8f4238');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, 8);
  ctx.fill();
  ctx.strokeStyle = '#6f332c';
  ctx.lineWidth = 3;
  ctx.stroke();
  // telhas
  ctx.strokeStyle = 'rgba(0,0,0,0.14)';
  ctx.lineWidth = 1.5;
  for (let i = 12; i < w; i += 16) {
    ctx.beginPath();
    ctx.moveTo(x + i, y + 4);
    ctx.lineTo(x + i, y + h - 4);
    ctx.stroke();
  }
  // platibanda clara
  ctx.strokeStyle = '#e8e2d6';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.roundRect(x + 2.5, y + 2.5, w - 5, h - 5, 7);
  ctx.stroke();
  // painel com o nome
  ctx.fillStyle = 'rgba(20,28,34,0.82)';
  ctx.beginPath();
  ctx.roundRect(x + w / 2 - 210, y + h / 2 - 15, 420, 30, 7);
  ctx.fill();
  ctx.fillStyle = '#f2f5f7';
  ctx.font = 'bold 16px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('COL. ESTADUAL BARBOSA FERRAZ', x + w / 2, y + h / 2 + 6);
  ctx.textAlign = 'left';
  // portao principal
  ctx.fillStyle = '#6a7a5f';
  ctx.beginPath();
  ctx.roundRect(x + w / 2 - 46, y + h - 2, 92, 34, 6);
  ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.18)';
  ctx.fillRect(x + w / 2 - 40, y + h + 2, 6, 28);
  ctx.fillRect(x + w / 2 - 14, y + h + 2, 6, 28);
  ctx.fillRect(x + w / 2 + 12, y + h + 2, 6, 28);
}

function court(ctx, x, y, w, h) {
  ctx.fillStyle = 'rgba(30,44,26,0.25)';
  ctx.beginPath();
  ctx.roundRect(x + 4, y + 5, w, h, 12);
  ctx.fill();
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, '#4d9166');
  g.addColorStop(1, '#3c7a52');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, 12);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.85)';
  ctx.lineWidth = 2.5;
  ctx.strokeRect(x + 14, y + 14, w - 28, h - 28);
  ctx.beginPath();
  ctx.moveTo(x + w / 2, y + 14);
  ctx.lineTo(x + w / 2, y + h - 14);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(x + w / 2, y + h / 2, 36, 0, TAU);
  ctx.stroke();
  // tabela de basquete
  ctx.fillStyle = '#3d4750';
  ctx.beginPath();
  ctx.roundRect(x + w / 2 - 4, y - 18, 8, 20, 3);
  ctx.fill();
  ctx.fillRect(x + w / 2 - 26, y - 32, 52, 16);
}

function garden(ctx, x, y, w, h) {
  ctx.fillStyle = 'rgba(30,44,26,0.25)';
  ctx.beginPath();
  ctx.roundRect(x + 4, y + 5, w, h, 10);
  ctx.fill();
  ctx.fillStyle = '#7a5433';
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, 10);
  ctx.fill();
  const r = mulberry(77);
  for (let row = 0; row < 4; row++) {
    const ry = y + 18 + row * ((h - 30) / 4);
    ctx.fillStyle = '#8f6540';
    ctx.beginPath();
    ctx.roundRect(x + 8, ry, w - 16, (h - 30) / 4 - 8, 6);
    ctx.fill();
    for (let i = 0; i < 5; i++) {
      const px = x + 24 + i * ((w - 40) / 5) + r() * 5;
      ctx.fillStyle = '#4f9445';
      ctx.beginPath();
      ctx.ellipse(px, ry + 12, 12, 9, 0, 0, TAU);
      ctx.fill();
      if (r() > 0.5) {
        ctx.fillStyle = '#f2d14c';
        ctx.beginPath();
        ctx.arc(px, ry + 8, 4, 0, TAU);
        ctx.fill();
      }
    }
  }
  // cerca
  ctx.strokeStyle = '#6f7a62';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, 10);
  ctx.stroke();
}
