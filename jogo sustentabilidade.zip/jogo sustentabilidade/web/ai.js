// NPC "Turista IA": conversa livre via API compativel com OpenAI.
// A chave e digitada pelo usuario e guardada so em sessionStorage.

import { act } from './bridge.js';

const DEFAULT_ENDPOINT = 'https://api.openai.com/v1/chat/completions';
const DEFAULT_MODEL = 'gpt-4o-mini';

const SYSTEM = `Você é o "Turista IA", morador de Ivaiporã, cidade do Vale do Ivaí no Paraná.
Você ajuda crianças e adolescentes que estão jogando um jogo sobre coleta seletiva.

Contexto local que você pode usar:
- Ivaiporã tem três praças temáticas no centro: Praça França (réplica da Torre Eiffel),
  Praça Espanha (chafariz, no Largo Mal. Deodoro) e Praça Japão (portão torii e lago).
- Perto: Terminal Rodoviário, Parque Ambiental Jardim Botânico, Lago de Furnas, Paróquia Bom Jesus.
- O Colégio Estadual Barbosa Ferraz fica na Rua Rio Grande do Sul, 1200, no Centro.
  Tem cerca de mil alunos e um Clube de Ciências com projetos de compostagem, horta escolar,
  bioplástico e captação de água da chuva.
- A cidade é conhecida como capital do milho.

Regras:
- Responda em português do Brasil, de forma curta e amigável: no máximo 4 frases.
- Explique de onde vem a reciclagem e onde cada material deve ser jogado.
- Se a pergunta não tiver a ver com reciclagem ou com a cidade, redirecione para o assunto.
- Nunca invente dados sobre Ivaiporã. Se não souber, diga que não tem certeza.`;

const el = {
  panel: document.getElementById('ai'),
  open: document.getElementById('ai-open'),
  close: document.getElementById('ai-close'),
  log: document.getElementById('ai-log'),
  form: document.getElementById('ai-form'),
  input: document.getElementById('ai-input'),
  endpoint: document.getElementById('ai-endpoint'),
  model: document.getElementById('ai-model'),
  key: document.getElementById('ai-key'),
  save: document.getElementById('ai-save'),
  cfg: document.getElementById('cfg'),
};

const LS = 'coleta-certinha-ia';

let history = [];
let busy = false;

function load() {
  try {
    const raw = sessionStorage.getItem(LS);
    if (!raw) return;
    const c = JSON.parse(raw);
    el.endpoint.value = c.endpoint || DEFAULT_ENDPOINT;
    el.model.value = c.model || DEFAULT_MODEL;
    el.key.value = c.key || '';
  } catch {
    /* nada guardado */
  }
}

function store() {
  sessionStorage.setItem(
    LS,
    JSON.stringify({
      endpoint: el.endpoint.value.trim(),
      model: el.model.value.trim(),
      key: el.key.value.trim(),
    })
  );
}

function say(who, text, cls) {
  const div = document.createElement('div');
  div.className = `msg ${cls || who}`;
  div.textContent = text;
  el.log.appendChild(div);
  el.log.scrollTop = el.log.scrollHeight;
  return div;
}

function toggle(open) {
  const willOpen = open ?? el.panel.classList.contains('closed');
  el.panel.classList.toggle('closed', !willOpen);
  el.open.classList.toggle('hide', willOpen);
  if (willOpen) el.input.focus();
}

async function ask(text) {
  const key = el.key.value.trim();
  const endpoint = el.endpoint.value.trim() || DEFAULT_ENDPOINT;
  const model = el.model.value.trim() || DEFAULT_MODEL;

  if (!key) {
    el.cfg.open = true;
    say('sys', 'Coloque sua chave na seção "Conexão com a IA" para conversar.', 'err');
    el.key.focus();
    return;
  }

  history.push({ role: 'user', content: text });
  say('me', text);
  busy = true;
  el.form.querySelector('button').disabled = true;
  const wait = say('bot', '...', 'bot');

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model,
        messages: [{ role: 'system', content: SYSTEM }, ...history],
        max_tokens: 260,
        temperature: 0.6,
      }),
    });

    if (!res.ok) {
      const detail = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status} ${detail.slice(0, 160)}`);
    }

    const data = await res.json();
    const reply = data?.choices?.[0]?.message?.content ?? '(resposta vazia)';
    wait.textContent = reply;
    history.push({ role: 'assistant', content: reply });
    act.aiUsed();
  } catch (err) {
    wait.remove();
    const msg = String(err.message || err);
    say(
      'sys',
      msg.includes('Failed to fetch')
        ? 'Não deu para contatar o servidor. Se a API bloquear o navegador, é preciso usar um proxy.'
        : `Falhou: ${msg}`,
      'err'
    );
  } finally {
    busy = false;
    el.form.querySelector('button').disabled = false;
    el.input.focus();
  }
}

export function initAi() {
  load();
  el.open.addEventListener('click', () => toggle(true));
  el.close.addEventListener('click', () => toggle(false));
  el.save.addEventListener('click', () => {
    store();
    say('sys', 'Conexão salva só nesta aba.');
  });
  el.form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = el.input.value.trim();
    if (!text || busy) return;
    el.input.value = '';
    ask(text);
  });

  say(
    'bot',
    'Oi! Eu sou o Turista IA. Pergunte sobre reciclagem, coleta seletiva ou sobre Ivaiporã.'
  );
}
