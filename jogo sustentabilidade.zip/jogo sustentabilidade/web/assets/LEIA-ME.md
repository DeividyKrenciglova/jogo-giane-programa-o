# Fotos reais (opcional)

O jogo desenha os dois lugares inteiros no canvas, então roda sem nenhuma imagem.

Se você tiver fotos com direito de uso da **Praça Espanha** e do **Colégio Estadual
Barbosa Ferraz**, coloque aqui com estes nomes exatos:

| arquivo              | o que aparece                        |
|----------------------|--------------------------------------|
| `praca-espanha.jpg`  | fundo da cena da praça (Largo Mal. Deodoro) |
| `barbosa-ferraz.jpg`  | fundo da cena da escola (Rua Rio Grande do Sul, 1200) |

Pontos de atenção:

- **Direitos de imagem.** Foto de boa qualidade de lugar público quase sempre tem
  autor. Para uso em sala de aula, o mais seguro é photographar você mesmo com o
  celular, ou usar imagem de licença aberta (Creative Commons) creditando o autor.
- A foto é desenhada **por cima** do cenário com 90% de opacidade. O lixo, as
  lixeiras, as pessoas e o HUD continuam desenhados por cima dela, então o jogo
  continua legível.
- Funciona melhor em **1280x720** ou maior, com o assunto centralizado.
- O navegador procura o arquivo sozinho. Se o nome estiver errado ou faltar, o
  jogo segue usando o desenho e não dá nenhum erro.
