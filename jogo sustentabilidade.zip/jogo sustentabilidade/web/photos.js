// Fotos reais dos lugares, se você tiver o direito de usar.
//
// Basta colocar a imagem em web/assets/ com um destes nomes:
//   praca-espanha.jpg  -> fundo da cena 0
//   barbosa-ferraz.jpg  -> fundo da cena 1
//
// Se o arquivo não existir, o jogo desenha o cenário completo no canvas.
// A foto é sobreposta por cima do desenho, então o lixo, as lixeiras e as
// pessoas continuam sendo desenhados por cima dela.

const SOURCES = ['assets/praca-espanha.jpg', 'assets/barbosa-ferraz.jpg'];

export const photos = SOURCES.map((src) => {
  const img = new Image();
  img.onerror = () => {};
  img.src = src;
  return img;
});
