// Ponte entre o JS e o modulo Rust compilado para wasm32.
// Sem wasm-bindgen: os numeros sao lidos direto do valor de retorno e as
// strings passam por um buffer unico que o Rust preenche.

const dec = new TextDecoder('utf-8');

export const K_DECO = 1;
export const K_TRASH = 2;
export const K_BIN = 3;
export const K_NPC = 4;
export const K_INFO = 5;
export const K_EXIT = 6;

export const PHASE_TITLE = 0;
export const PHASE_PLAY = 1;
export const PHASE_TALK = 2;
export const PHASE_END = 3;

export const TONE = { INFO: 0, OK: 1, BAD: 2, AI: 3 };

export const EV = {
  NONE: 0,
  BEGIN: 1,
  CORRECT: 2,
  WRONG: 3,
  PICK: 4,
  DROP: 5,
  BIN_EMPTY: 6,
  TALK: 7,
  INFO: 8,
  SCENE: 9,
  FINISH: 10,
};

let wasm = null;
let ex = null;

/** Carrega o .wasm e devolve os exports. */
export async function load(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`nao achei o wasm em ${url} (${res.status})`);
  const bytes = await res.arrayBuffer();
  const { instance } = await WebAssembly.instantiate(bytes, {});
  wasm = instance.exports;
  ex = wasm;
  return wasm;
}

/** Le a string que o Rust acabou de escrever no buffer de saida. */
function readText() {
  const p = ex.text_ptr();
  const n = ex.text_len();
  if (n === 0) return '';
  return dec.decode(new Uint8Array(wasm.memory.buffer, p, n));
}

function text(getter) {
  ex[getter]();
  return readText();
}

// ------------------------------------------------------------------ consulta

export const get = {
  phase: () => ex.phase(),
  scene: () => ex.scene(),
  score: () => ex.score(),
  streak: () => ex.streak(),
  bestStreak: () => ex.best_streak(),
  elapsed: () => ex.elapsed(),
  held: () => ex.held(),
  heldBin: () => ex.held_bin(),
  tone: () => ex.msg_tone(),
  ended: () => ex.ended(),
  facts: () => ex.facts(),
  correct: () => ex.correct(),
  wrong: () => ex.wrong(),
  total: () => ex.total(),
  aiTurns: () => ex.ai_turns(),
  trashLeft: () => ex.trash_left(),
  isTalked: (i) => ex.is_talked(i) === 1,
  objCount: () => ex.obj_count(),
  dlgLines: () => ex.dlg_lines(),
  dlgChoices: () => ex.dlg_choices(),
  width: () => ex.world_w(),
  height: () => ex.world_h(),
  obj: (i, field) => ex.obj_field(i, field),
};

export const objKind = (i) => ex.obj_field(i, 0);
export const objVariant = (i) => ex.obj_field(i, 1);
export const objX = (i) => ex.obj_field(i, 2);
export const objY = (i) => ex.obj_field(i, 3);
export const objW = (i) => ex.obj_field(i, 4);
export const objH = (i) => ex.obj_field(i, 5);
export const objAlive = (i) => ex.obj_field(i, 6) === 1;

export const textOf = {
  msg: () => text('text_msg'),
  sceneTitle: () => text('text_scene_title'),
  sceneSub: () => text('text_scene_sub'),
  objLabel: (i) => {
    ex.text_obj_label(i);
    return readText();
  },
  trashName: (v) => {
    ex.text_trash_name(v);
    return readText();
  },
  trashTip: (v) => {
    ex.text_trash_tip(v);
    return readText();
  },
  trashBody: (v) => {
    ex.text_trash_body(v);
    return readText();
  },
  trashCap: (v) => {
    ex.text_trash_cap(v);
    return readText();
  },
  binName: (v) => {
    ex.text_bin_name(v);
    return readText();
  },
  binColor: (v) => {
    ex.text_bin_color(v);
    return readText();
  },
  npcName: (v) => {
    ex.text_npc_name(v);
    return readText();
  },
  speaker: () => text('text_dlg_speaker'),
  line: (i) => {
    ex.text_dlg_line(i);
    return readText();
  },
  choice: (i) => {
    ex.text_dlg_choice(i);
    return readText();
  },
};

// -------------------------------------------------------------------- acoes

export const act = {
  start: () => ex.start(),
  tick: (dt) => ex.tick(dt),
  pointerDown: (x, y) => ex.pointer_down(x, y),
  pointerUp: (x, y, moved) => ex.pointer_up(x, y, moved),
  click: (x, y) => ex.click(x, y),
  choose: (i) => ex.choose(i),
  aiUsed: () => ex.ai_used(),
};
