// Desenha o quadro: cenario, objetos, HUD, dialogo e telas de inicio/fim.

import {
  get, objKind, objVariant, objX, objY, objW, objH, objAlive, textOf,
  PHASE_TITLE, PHASE_TALK, PHASE_END, TONE,
  K_DECO, K_INFO, K_EXIT, K_NPC, K_BIN, K_TRASH,
} from './bridge.js';
import { drawPraca, drawEscola } from './map.js';
import { trashSprite, treeSprite, benchSprite } from './sprites.js';
import { shadow, glow, tag, wrapText, roundRect, badge, vignette } from './art.js';
import { photos } from './photos.js';

const NPC_SHIRT = ['#d05a44', '#4a6fa5', '#3f9070', '#8a5fa8', '#c39a34'];
const NPC_HAIR = ['#5b4a3a', '#b8b4ae', '#2f2a26', '#4a3b5c', '#3a2c22'];
const BIN_LETTER = ['R', 'O', 'N'];

// faixasverticais da tela
const TOP_BAND = 64;    // HUD superior
const MSG_BAND = 664;   // base da faixa de mensagem
const LEG_Y = 676;      // inicio da faixa de legenda

export function draw(ctx, mouse, t) {
  const scene = get.scene();
  ctx.clearRect(0, 0, 1280, 720);

  if (scene === 0) drawPraca(ctx, t);
  else drawEscola(ctx);

  // foto real, se o usuario colocou uma em assets/
  const bg = photos[scene];
  if (bg && bg.complete && bg.naturalWidth) {
    ctx.save();
    ctx.globalAlpha = 0.88;
    ctx.drawImage(bg, 0, 0, 1280, 720);
    ctx.restore();
    ctx.fillStyle = 'rgba(12,18,22,0.28)';
    ctx.fillRect(0, 0, 1280, 720);
  }

  vignette(ctx, 1280, 720, 0.16);

  drawObjects(ctx, mouse, t);
  drawHud(ctx);

  if (get.phase() === PHASE_TITLE) drawTitle(ctx);
  if (get.phase() === PHASE_END) drawEnd(ctx);
  if (get.phase() === PHASE_TALK) drawDialogue(ctx, mouse);
}

// ------------------------------------------------------------------ objetos

function drawObjects(ctx, mouse, t) {
  const n = get.objCount();
  const held = get.held();

  for (const layer of [K_DECO, K_INFO, K_EXIT, K_NPC, K_BIN, K_TRASH]) {
    for (let i = 0; i < n; i++) {
      if (objKind(i) !== layer) continue;
      if (layer === K_TRASH && !objAlive(i)) continue;
      if (held >= 0 && i === held) continue;
      drawOne(ctx, i, mouse, t);
    }
  }

  // o item na mao segue o cursor, com uma sombra maior
  if (held >= 0) {
    const v = objVariant(held);
    const body = textOf.trashBody(v);
    const cap = textOf.trashCap(v);
    const name = textOf.trashName(v);
    const spr = trashSprite(v, [body, cap]);
    const hovering = binUnder(mouse) >= 0;
    ctx.save();
    if (hovering) {
      ctx.shadowColor = 'rgba(63,155,70,0.85)';
      ctx.shadowBlur = 26;
    }
    shadow(ctx, mouse.x + 5, mouse.y + 26, 26, 9, 0.28);
    ctx.drawImage(spr, mouse.x - 40, mouse.y - 46, 80, 80);
    ctx.restore();
    tag(ctx, mouse.x, mouse.y - 44, name, { size: 12 });
  }
}

/** Qual lixeira esta sob o ponto (para o destaque do arrasto). */
function binUnder(mouse) {
  const n = get.objCount();
  for (let i = 0; i < n; i++) {
    if (objKind(i) !== K_BIN) continue;
    const x = objX(i);
    const y = objY(i);
    const w = objW(i);
    const h = objH(i);
    const cx = x + w / 2;
    const cy = y + h / 2;
    if (Math.abs(mouse.x - cx) <= w / 2 + 10 && Math.abs(mouse.y - cy) <= h / 2 + 10) return i;
  }
  return -1;
}

function drawOne(ctx, i, mouse, t) {
  const k = objKind(i);
  const v = objVariant(i);
  const x = objX(i);
  const y = objY(i);
  const w = objW(i);
  const h = objH(i);
  const cx = x + w / 2;
  const cy = y + h / 2;
  const hover = mouse.x >= x - 6 && mouse.x <= x + w + 6 && mouse.y >= y - 6 && mouse.y <= y + h + 6;

  switch (k) {
    case K_DECO: {
      if (v === 0) {
        const spr = treeSprite(i % 3);
        ctx.drawImage(spr, cx - w / 2, cy - h / 2, w, h);
      } else if (v === 1) {
        const spr = benchSprite();
        ctx.drawImage(spr, cx - w / 2, cy - h / 2, w + 8, h + 8);
      }
      break;
    }

    case K_BIN:
      drawBin(ctx, cx, cy, w / 2, v, hover, get.heldBin() === v);
      break;

    case K_NPC:
      drawNpc(ctx, cx, cy, v, hover, get.isTalked(v), t);
      break;

    case K_TRASH: {
      const spr = trashSprite(v, [textOf.trashBody(v), textOf.trashCap(v)]);
      // leve "flutuar" para chamar atencao
      const bob = Math.sin(t * 2 + i * 1.7) * 1.6;
      shadow(ctx, cx + 3, cy + 24, 22, 8, 0.24);
      if (hover) {
        ctx.save();
        ctx.shadowColor = 'rgba(255,205,80,0.8)';
        ctx.shadowBlur = 18;
        ctx.drawImage(spr, cx - 38, cy - 38 + bob, 76, 76);
        ctx.restore();
      } else {
        ctx.drawImage(spr, cx - 34, cy - 34 + bob, 68, 68);
      }
      if (hover) tag(ctx, cx, cy - 34 + bob, textOf.trashName(v), { y0: 34, bg: '#3d3320' });
      break;
    }

    case K_EXIT:
      drawExit(ctx, x, y, w, h, textOf.objLabel(i), hover);
      break;

    case K_INFO:
      if (hover) {
        ctx.save();
        ctx.fillStyle = 'rgba(255,214,106,0.16)';
        ctx.strokeStyle = 'rgba(255,214,106,0.9)';
        ctx.lineWidth = 2.5;
        ctx.setLineDash([9, 7]);
        ctx.beginPath();
        ctx.roundRect(x, y, w, h, 14);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
        tag(ctx, cx, cy, `${textOf.objLabel(i)} — clique para ler`, { bg: '#3d3320', size: 13 });
      }
      break;

    default:
      break;
  }
}

/** Lixeira vista de cima: aro colorido, tampa e etiqueta. */
function drawBin(ctx, cx, cy, r, variant, hover, isTarget) {
  const color = textOf.binColor(variant);
  const name = textOf.binName(variant);

  shadow(ctx, cx + 3, cy + 6, r * 0.9, r * 0.7, 0.26);
  // corpo
  ctx.fillStyle = shadeHex(color, -0.35);
  ctx.beginPath();
  ctx.ellipse(cx, cy, r * 0.86, r * 0.74, 0, 0, Math.PI * 2);
  ctx.fill();
  // tampa
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.ellipse(cx, cy - 3, r * 0.8, r * 0.68, 0, 0, Math.PI * 2);
  ctx.fill();
  // abertura
  ctx.fillStyle = 'rgba(12,16,20,0.8)';
  ctx.beginPath();
  ctx.ellipse(cx, cy - 3, r * 0.4, r * 0.32, 0, 0, Math.PI * 2);
  ctx.fill();
  // triângulo de simbolo
  ctx.fillStyle = 'rgba(255,255,255,0.85)';
  ctx.beginPath();
  ctx.moveTo(cx, cy - 12);
  ctx.lineTo(cx + 11, cy + 5);
  ctx.lineTo(cx - 11, cy + 5);
  ctx.closePath();
  ctx.fill();

  if (isTarget) {
    ctx.save();
    ctx.strokeStyle = '#b6f0c2';
    ctx.lineWidth = 4;
    ctx.setLineDash([9, 7]);
    ctx.beginPath();
    ctx.ellipse(cx, cy, r * 1.08, r * 0.96, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  } else if (hover) {
    glow(ctx, cx - r, cy - r * 0.8, r * 2, r * 1.6, '#ffe08a');
  }

  tag(ctx, cx, cy + r * 0.72, name, { bg: hexToRgba(color, 0.95), size: 12 });
}

/** Pessoa vista de cima: cabeca, ombros e o nome. */
function drawNpc(ctx, cx, cy, v, hover, talked, t) {
  const shirt = NPC_SHIRT[v % NPC_SHIRT.length];
  const hair = NPC_HAIR[v % NPC_HAIR.length];
  const bob = Math.sin(t * 1.5 + v) * 1.2;

  shadow(ctx, cx + 2, cy + 14, 19, 8, 0.28);
  // ombros / tronco
  ctx.fillStyle = shirt;
  ctx.beginPath();
  ctx.ellipse(cx, cy + 3 + bob, 17, 19, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.14)';
  ctx.beginPath();
  ctx.ellipse(cx - 5, cy - 3 + bob, 10, 11, -0.4, 0, Math.PI * 2);
  ctx.fill();
  // bracos
  ctx.fillStyle = shadeHex(shirt, -0.18);
  ctx.beginPath();
  ctx.ellipse(cx - 18, cy + 4 + bob, 5.5, 9, 0.3, 0, Math.PI * 2);
  ctx.ellipse(cx + 18, cy + 4 + bob, 5.5, 9, -0.3, 0, Math.PI * 2);
  ctx.fill();
  // cabeca
  ctx.fillStyle = '#e8bd95';
  ctx.beginPath();
  ctx.arc(cx, cy - 9 + bob, 11, 0, Math.PI * 2);
  ctx.fill();
  // cabelo
  ctx.fillStyle = hair;
  ctx.beginPath();
  ctx.arc(cx, cy - 11 + bob, 11, Math.PI * 1.02, Math.PI * 1.98);
  ctx.fill();
  // olhos (olhando para a camera/cima)
  ctx.fillStyle = '#2a2118';
  ctx.beginPath();
  ctx.arc(cx - 4, cy - 11 + bob, 1.5, 0, Math.PI * 2);
  ctx.arc(cx + 4, cy - 11 + bob, 1.5, 0, Math.PI * 2);
  ctx.fill();

  if (hover) glow(ctx, cx - 22, cy - 26, 44, 48, '#ffe08a');
  tag(ctx, cx, cy + 20, textOf.npcName(v), {
    size: 11,
    bg: talked ? 'rgba(40,86,50,0.9)' : 'rgba(20,28,34,0.88)',
  });
}

function drawExit(ctx, x, y, w, h, label, hover) {
  shadow(ctx, x + w / 2 + 2, y + h + 2, w * 0.42, 7, 0.24);
  ctx.fillStyle = hover ? '#2f7a48' : '#22603a';
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, 12);
  ctx.fill();
  ctx.strokeStyle = '#9fe6b4';
  ctx.lineWidth = 2.5;
  ctx.stroke();
  // seta
  ctx.fillStyle = '#eefaf2';
  ctx.beginPath();
  const ax = x + 24;
  const ay = y + h / 2;
  ctx.moveTo(ax, ay - 9);
  ctx.lineTo(ax + 12, ay);
  ctx.lineTo(ax, ay + 9);
  ctx.closePath();
  ctx.fill();
  ctx.font = 'bold 12.5px system-ui, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillStyle = '#eefaf2';
  ctx.fillText(label, x + 44, y + h / 2 + 4.5);
}

// ---------------------------------------------------------------------- HUD

function drawHud(ctx) {
  // barra superior
  ctx.fillStyle = 'rgba(13,19,24,0.9)';
  ctx.fillRect(0, 0, 1280, TOP_BAND + 2);
  ctx.strokeStyle = 'rgba(255,255,255,0.08)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, TOP_BAND + 2.5);
  ctx.lineTo(1280, TOP_BAND + 2.5);
  ctx.stroke();

  ctx.fillStyle = '#eef4f7';
  ctx.font = 'bold 17px system-ui, sans-serif';
  ctx.fillText(textOf.sceneTitle(), 18, 27);
  ctx.font = '12px system-ui, sans-serif';
  ctx.fillStyle = '#93a4b0';
  ctx.fillText(textOf.sceneSub(), 18, 46);

  // progresso
  const left = get.trashLeft();
  const total = get.total();
  const done = total - left;
  const pct = total ? done / total : 0;
  ctx.font = '12px system-ui, sans-serif';
  ctx.fillStyle = '#93a4b0';
  ctx.fillText('lixo no chão', 330, 24);
  ctx.fillStyle = 'rgba(255,255,255,0.1)';
  ctx.beginPath();
  ctx.roundRect(330, 31, 240, 15, 8);
  ctx.fill();
  ctx.fillStyle = '#3f9b46';
  ctx.beginPath();
  ctx.roundRect(330, 31, Math.max(4, 240 * pct), 15, 8);
  ctx.fill();
  ctx.fillStyle = '#eef4f7';
  ctx.font = 'bold 12px system-ui, sans-serif';
  ctx.fillText(`${done} de ${total}`, 340, 43);

  // placar
  ctx.font = 'bold 19px system-ui, sans-serif';
  ctx.fillStyle = '#ffd76a';
  ctx.fillText(`${get.score()} pts`, 600, 36);
  ctx.font = '11px system-ui, sans-serif';
  ctx.fillStyle = '#93a4b0';
  ctx.fillText(`sequência ${get.streak()}`, 600, 52);

  // acertos / erros / fatos
  ctx.font = '12px system-ui, sans-serif';
  ctx.fillStyle = '#9fe6b4';
  ctx.fillText(`${get.correct()} acertos`, 700, 30);
  ctx.fillStyle = '#f0a58f';
  ctx.fillText(`${get.wrong()} erros`, 700, 47);
  ctx.fillStyle = '#93a4b0';
  ctx.fillText(`${get.facts()} fatos aprendidos`, 790, 47);

  // tempo decorrido
  const s = Math.floor(get.elapsed());
  ctx.font = '12px system-ui, sans-serif';
  ctx.fillStyle = '#93a4b0';
  ctx.textAlign = 'right';
  ctx.fillText('tempo', 1262, 24);
  ctx.font = 'bold 16px system-ui, sans-serif';
  ctx.fillStyle = '#eef4f7';
  ctx.fillText(`${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`, 1262, 45);
  ctx.textAlign = 'left';

  // legenda das lixeiras, no rodape
  drawLegend(ctx);
  drawMessage(ctx);
}

function drawLegend(ctx) {
  const y = LEG_Y;
  ctx.fillStyle = 'rgba(13,19,24,0.92)';
  ctx.fillRect(0, y, 1280, 720 - y);
  ctx.strokeStyle = 'rgba(255,255,255,0.07)';
  ctx.beginPath();
  ctx.moveTo(0, y + 0.5);
  ctx.lineTo(1280, y + 0.5);
  ctx.stroke();

  ctx.font = 'bold 12px system-ui, sans-serif';
  ctx.fillStyle = '#93a4b0';
  ctx.fillText('ARRASTE O LIXO ATÉ A LIXEIRA CERTA', 20, y + 28);

  for (let b = 0; b < 3; b++) {
    const x = 430 + b * 190;
    const color = textOf.binColor(b);
    const name = textOf.binName(b);
    const target = get.heldBin() === b;
    roundRect(ctx, x, y + 4, 176, 36, 9, target ? hexToRgba(color, 0.32) : 'rgba(255,255,255,0.06)',
      target ? color : 'rgba(255,255,255,0.12)');
    badge(ctx, x + 24, y + 22, 13, color, BIN_LETTER[b]);
    ctx.font = 'bold 13px system-ui, sans-serif';
    ctx.fillStyle = target ? '#ffffff' : '#cbd6dd';
    ctx.fillText(name, x + 46, y + 27);
  }

  const held = get.held() >= 0;
  ctx.font = '12px system-ui, sans-serif';
  ctx.fillStyle = held ? '#ffd76a' : '#6f8090';
  ctx.textAlign = 'right';
  ctx.fillText(
    held ? `na mão: ${textOf.trashName(objVariant(get.held()))} — solte na lixeira` : 'nada na mão',
    1262,
    y + 27
  );
  ctx.textAlign = 'left';
}

function drawMessage(ctx) {
  const msg = textOf.msg();
  if (!msg || get.phase() === PHASE_TALK) return;
  const tone = get.tone();
  const bg = tone === TONE.OK ? 'rgba(30,84,48,0.95)' : tone === TONE.BAD ? 'rgba(112,44,32,0.95)' : 'rgba(16,24,30,0.92)';
  ctx.font = '14px system-ui, sans-serif';
  const h = 32 + (ctx.measureText(msg).width > 1180 ? 19 : 0);
  roundRect(ctx, 18, MSG_BAND - h, 1244, h, 10, bg, 'rgba(255,255,255,0.14)');
  ctx.fillStyle = '#f2f7f9';
  wrapText(ctx, msg, 34, MSG_BAND - h + 23, 1212, 19);
}

// -------------------------------------------------------------------- telas

function panel(ctx, title, subtitle, lines, accent, footer) {
  ctx.fillStyle = 'rgba(8,12,16,0.72)';
  ctx.fillRect(0, 0, 1280, 720);
  ctx.fillStyle = accent;
  ctx.beginPath();
  ctx.roundRect(220, 150, 840, 420, 20);
  ctx.fill();
  ctx.fillStyle = '#131c22';
  ctx.beginPath();
  ctx.roundRect(232, 162, 816, 396, 16);
  ctx.fill();

  ctx.fillStyle = accent;
  ctx.font = 'bold 30px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(title, 640, 218);
  ctx.font = '14px system-ui, sans-serif';
  ctx.fillStyle = '#8fa3b0';
  ctx.fillText(subtitle, 640, 244);

  ctx.font = '16px system-ui, sans-serif';
  ctx.fillStyle = '#dbe5ea';
  lines.forEach((l, i) => ctx.fillText(l, 640, 288 + i * 28));

  ctx.fillStyle = accent;
  ctx.font = 'bold 15px system-ui, sans-serif';
  ctx.fillText(footer, 640, 528);
  ctx.textAlign = 'left';
}

function drawTitle(ctx) {
  panel(
    ctx,
    'Coleta Certinha',
    'Ivaiporã - PR: Praça Espanha e Colégio Estadual Barbosa Ferraz',
    [
      'Pegue o lixo que está no chão e ARRASTE até a lixeira certa.',
      'Azul: recicláveis   •   Verde: orgânicos   •   Vermelho: não recicláveis',
      'Converse com os moradores e com a Turista IA para aprender mais.',
      '',
      'Não tem vida nem tempo limite — errar só ensina.',
    ],
    '#3f9b46',
    'clique ou toque para começar'
  );
}

function drawEnd(ctx) {
  const total = get.total();
  const right = get.correct();
  const pct = total ? Math.round((right / total) * 100) : 0;
  const s = Math.floor(get.elapsed());
  const perfect = get.wrong() === 0;
  panel(
    ctx,
    'Todos os lixos foram para o lugar certo!',
    `Ivaiporã fica mais limpa com ${get.facts()} fatos aprendidos por você`,
    [
      `Pontuação: ${get.score()} pts`,
      `Acertos: ${right} de ${total} (${pct}%)   •   Melhor sequência: ${get.bestStreak()}`,
      `Tempo: ${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}` +
        (perfect ? '   •   Bônus sem nenhum erro!' : ''),
      '',
      'Aprenda mais no painel da Turista IA.',
    ],
    '#3f9b46',
    'clique ou toque para jogar de novo'
  );
}

// ------------------------------------------------------------------ dialogo

export const dialogueHits = [];

function drawDialogue(ctx, mouse) {
  ctx.fillStyle = 'rgba(6,10,14,0.55)';
  ctx.fillRect(0, 0, 1280, 720);

  const x = 110;
  const y = 396;
  const w = 1060;
  const h = 290;
  ctx.fillStyle = '#131c22';
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, 16);
  ctx.fill();
  ctx.strokeStyle = '#3f9b46';
  ctx.lineWidth = 3;
  ctx.stroke();

  // nome com faixa
  const speaker = textOf.speaker();
  ctx.font = 'bold 17px system-ui, sans-serif';
  const nw = ctx.measureText(speaker).width + 30;
  ctx.fillStyle = '#3f9b46';
  ctx.beginPath();
  ctx.roundRect(x + 24, y - 15, nw, 30, 8);
  ctx.fill();
  ctx.fillStyle = '#0f1a13';
  ctx.fillText(speaker, x + 39, y + 6);

  // falas
  ctx.font = '15px system-ui, sans-serif';
  ctx.fillStyle = '#dde6eb';
  let ly = y + 44;
  for (let i = 0; i < get.dlgLines(); i++) {
    ly = wrapText(ctx, textOf.line(i), x + 28, ly, w - 56, 20) + 6;
  }

  // opcoes
  dialogueHits.length = 0;
  const n = get.dlgChoices();
  const cw = w - 56;
  const rows = [];
  let yy = y + h - 22;
  for (let i = n - 1; i >= 0; i--) {
    const label = textOf.choice(i);
    ctx.font = '14px system-ui, sans-serif';
    const bw = Math.min(cw, ctx.measureText(label).width + 40);
    rows.unshift({ i, label, bw, by: yy - 28 });
    yy -= 34;
  }
  for (const r of rows) {
    const hov = mouse.x >= x + 28 && mouse.x <= x + 28 + r.bw && mouse.y >= r.by && mouse.y <= r.by + 28;
    ctx.fillStyle = hov ? '#3f9b46' : '#1e2a33';
    ctx.beginPath();
    ctx.roundRect(x + 28, r.by, r.bw, 28, 8);
    ctx.fill();
    ctx.strokeStyle = hov ? '#b6f0c2' : 'rgba(255,255,255,0.12)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = hov ? '#ffffff' : '#cbd6dd';
    ctx.font = '14px system-ui, sans-serif';
    ctx.fillText(r.label, x + 48, r.by + 19);
    dialogueHits.push({ x: x + 28, y: r.by, w: r.bw, h: 28, i: r.i });
  }
  dialogueHits.sort((a, b) => a.i - b.i);
}

// ------------------------------------------------------------------- cores

function hexToRgba(hex, a) {
  const s = hex.replace('#', '');
  const v = s.length === 3 ? s.split('').map((c) => c + c).join('') : s;
  const r = parseInt(v.slice(0, 2), 16);
  const g = parseInt(v.slice(2, 4), 16);
  const b = parseInt(v.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${a})`;
}

function shadeHex(hex, amt) {
  const s = hex.replace('#', '');
  const v = s.length === 3 ? s.split('').map((c) => c + c).join('') : s;
  const ch = [0, 2, 4].map((i) => {
    const c = parseInt(v.slice(i, i + 2), 16);
    return Math.max(0, Math.min(255, Math.round(c + 255 * amt)));
  });
  return `rgb(${ch[0]},${ch[1]},${ch[2]})`;
}
