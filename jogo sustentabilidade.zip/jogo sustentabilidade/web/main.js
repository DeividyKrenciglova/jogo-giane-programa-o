// Ponto de entrada: carrega o wasm, trata mouse/toque e roda o laco de quadro.
//
// Gesto principal: pressionar em um item, arrastar e soltar sobre a lixeira.
// Um toque curto (sem arrastar) deixa o item "colado" na mao, para quem
// preferir clicar na lixeira depois.

import { load, get, act, textOf, PHASE_TITLE, PHASE_TALK, PHASE_END, K_BIN, K_TRASH } from './bridge.js';
import { draw, dialogueHits } from './render.js';
import { initAi } from './ai.js';

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const loading = document.getElementById('loading');

const mouse = { x: -999, y: -999 };

// arraste
let dragging = false;
let downX = 0;
let downY = 0;

// ------------------------------------------------------------------ escala

function fit() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = 1280 * dpr;
  canvas.height = 720 * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
fit();
window.addEventListener('resize', fit);

function toGame(ev) {
  const r = canvas.getBoundingClientRect();
  mouse.x = ((ev.clientX - r.left) / r.width) * 1280;
  mouse.y = ((ev.clientY - r.top) / r.height) * 720;
}

function distFromDown() {
  return Math.hypot(mouse.x - downX, mouse.y - downY);
}

// ------------------------------------------------------------------- mouse

canvas.addEventListener('mousemove', (ev) => {
  toGame(ev);
  canvas.style.cursor = get.phase() === PHASE_PLAY && hoverable() ? 'grab' : 'default';
});

canvas.addEventListener('mousedown', (ev) => {
  if (ev.button !== 0) return;
  ev.preventDefault();
  toGame(ev);
  downX = mouse.x;
  downY = mouse.y;

  const phase = get.phase();
  if (phase === PHASE_TITLE || phase === PHASE_END) {
    act.click(mouse.x, mouse.y);
    return;
  }
  if (phase === PHASE_TALK) {
    handleDialogueClick();
    return;
  }
  dragging = true;
  act.pointerDown(mouse.x, mouse.y);
  canvas.style.cursor = 'grabbing';
});

canvas.addEventListener('mouseup', (ev) => {
  if (ev.button !== 0) return;
  toGame(ev);
  if (dragging) {
    act.pointerUp(mouse.x, mouse.y, distFromDown());
    dragging = false;
  }
  canvas.style.cursor = hoverable() ? 'grab' : 'default';
});

// sair da janela durante o arrasto solta o item
window.addEventListener('mouseup', () => {
  if (dragging) {
    act.pointerUp(mouse.x, mouse.y, distFromDown());
    dragging = false;
  }
});

canvas.addEventListener('mouseleave', () => {
  if (!dragging) {
    mouse.x = -999;
    mouse.y = -999;
  }
});

// ------------------------------------------------------------------- toque

canvas.addEventListener('touchstart', (ev) => {
  ev.preventDefault();
  const t = ev.changedTouches[0];
  toGame(t);
  downX = mouse.x;
  downY = mouse.y;
  const phase = get.phase();
  if (phase === PHASE_TITLE || phase === PHASE_END) {
    act.click(mouse.x, mouse.y);
    return;
  }
  if (phase === PHASE_TALK) {
    handleDialogueClick();
    return;
  }
  dragging = true;
  act.pointerDown(mouse.x, mouse.y);
}, { passive: false });

canvas.addEventListener('touchmove', (ev) => {
  ev.preventDefault();
  toGame(ev.changedTouches[0]);
}, { passive: false });

canvas.addEventListener('touchend', (ev) => {
  ev.preventDefault();
  toGame(ev.changedTouches[0]);
  if (dragging) {
    act.pointerUp(mouse.x, mouse.y, distFromDown());
    dragging = false;
  }
}, { passive: false });

// ----------------------------------------------------------------- teclado

window.addEventListener('keydown', (ev) => {
  const phase = get.phase();
  if (ev.key === 'Escape' && phase === PHASE_PLAY) {
    act.click(-50, -50);
    return;
  }
  if (ev.key >= '1' && ev.key <= '3' && phase === PHASE_PLAY) {
    const target = Number(ev.key) - 1;
    const n = get.objCount();
    for (let i = 0; i < n; i++) {
      if (get.obj(i, 0) === K_BIN && get.obj(i, 1) === target) {
        act.click(get.obj(i, 2) + get.obj(i, 4) / 2, get.obj(i, 3) + get.obj(i, 5) / 2);
        return;
      }
    }
  }
});

function handleDialogueClick() {
  for (const b of dialogueHits) {
    if (mouse.x >= b.x && mouse.x <= b.x + b.w && mouse.y >= b.y && mouse.y <= b.y + b.h) {
      act.choose(b.i);
      return;
    }
  }
}

/** Existe algo clicavel sob o mouse? */
function hoverable() {
  if (get.phase() !== PHASE_PLAY) return true;
  if (get.held() >= 0) return true;
  const n = get.objCount();
  const PAD = 10;
  for (let i = n - 1; i >= 0; i--) {
    const kind = get.obj(i, 0);
    if (kind === K_TRASH && get.obj(i, 6) === 0) continue;
    const x = get.obj(i, 2);
    const y = get.obj(i, 3);
    const w = get.obj(i, 4);
    const h = get.obj(i, 5);
    if (mouse.x >= x - PAD && mouse.x <= x + w + PAD && mouse.y >= y - PAD && mouse.y <= y + h + PAD) {
      return true;
    }
  }
  return false;
}

// -------------------------------------------------------------------- laco

let last = performance.now();
function loop(now) {
  const dt = Math.min((now - last) / 1000, 0.1);
  last = now;
  act.tick(dt);
  draw(ctx, mouse, now / 1000);
  requestAnimationFrame(loop);
}

// -------------------------------------------------------------------- boot

(async function boot() {
  try {
    await load('jogo.wasm');
  } catch (err) {
    loading.textContent = 'Nao achei o arquivo jogo.wasm. Rode ./build.sh antes de abrir a pagina.';
    loading.classList.remove('hidden');
    console.error(err);
    return;
  }
  loading.classList.add('hidden');
  initAi();
  requestAnimationFrame(loop);
})();

// atalhos para depurar no console do navegador
window.jogo = { get, act, textOf };
