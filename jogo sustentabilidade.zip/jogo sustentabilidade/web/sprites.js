// Sprites pre-renderizados.
//
// Cada sprite e desenhado uma unica vez num canvas fora da tela, em 2x, e
// depois so e copiado. Isso deixa o desenho nitido (independe dozoom da tela)
// e bem mais barato do que refazer vetores a cada quadro.
//
// Para adicionar um sprite: chame `sprite(chave, largura, altura, desenho)`.
// O `desenho` recebe um contexto ja transladado para o canto superior esquerdo
// do sprite e um fator de escala.

const SS = 2; // superamostragem
const cache = new Map();

/** Cria (ou reaproveita) um sprite. O desenho roda uma unica vez. */
export function sprite(key, w, h, draw) {
  let c = cache.get(key);
  if (c) return c;
  c = document.createElement('canvas');
  c.width = Math.ceil(w * SS);
  c.height = Math.ceil(h * SS);
  const g = c.getContext('2d');
  g.scale(SS, SS);
  g.translate(0, 0);
  draw(g, w, h);
  cache.set(key, c);
  return c;
}

/** Copia um sprite centrado em (cx, cy), com tamanho `size` (quadrado). */
export function blit(ctx, img, cx, cy, size, w, h, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.drawImage(img, cx - size / 2, cy - size / 2, size, size);
  ctx.restore();
}

// --------------------------------------------------------------- auxiliares

function outline(g, path, width, color) {
  g.save();
  g.strokeStyle = color;
  g.lineWidth = width;
  g.lineJoin = 'round';
  g.lineCap = 'round';
  path();
  g.stroke();
  g.restore();
}

function ellipsePath(g, x, y, rx, ry) {
  g.beginPath();
  g.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
}

function rrect(g, x, y, w, h, r) {
  g.beginPath();
  g.roundRect(x, y, w, h, r);
}

function vgrad(g, x, y0, y1, a, b) {
  const gr = g.createLinearGradient(x, y0, x, y1);
  gr.addColorStop(0, a);
  gr.addColorStop(1, b);
  return gr;
}

/** Contorno branco de "adesivo", que faz o item destacar no chao. */
function sticker(g, path, S) {
  g.save();
  g.shadowColor = 'rgba(0,0,0,0.35)';
  g.shadowBlur = 6 * S;
  g.shadowOffsetY = 2 * S;
  outline(g, path, 5.5 * S, '#f7faf2');
  g.restore();
  path();
  g.fill();
}

// ------------------------------------------------------------ lixo no chao

const BOX = 72; // sprite quadrado, item desenhado em ~54

/**
 * `colors` vem do Rust: [corpo, tampa].
 * O item e desenhado grande, com contorno claro e sombra propria.
 */
export function trashSprite(variant, colors) {
  const [body, cap] = colors;
  return sprite(`trash:${variant}:${body}:${cap}`, BOX, BOX, (g, S) => {
    const u = S / BOX; // 1.0 aqui; existe para deixar as medidas legiveis
    g.lineJoin = 'round';
    g.lineCap = 'round';

    const item = () => {
      switch (variant) {
        case 0: { // garrafa PET
          const p = () => {
            g.beginPath();
            g.moveTo(28 * u, 12 * u);
            g.lineTo(44 * u, 12 * u);
            g.lineTo(44 * u, 20 * u);
            g.quadraticCurveTo(52 * u, 26 * u, 52 * u, 36 * u);
            g.lineTo(52 * u, 60 * u);
            g.quadraticCurveTo(52 * u, 64 * u, 47 * u, 64 * u);
            g.lineTo(25 * u, 64 * u);
            g.quadraticCurveTo(20 * u, 64 * u, 20 * u, 60 * u);
            g.lineTo(20 * u, 36 * u);
            g.quadraticCurveTo(20 * u, 26 * u, 28 * u, 20 * u);
            g.closePath();
          };
          sticker(g, p, u);
          g.fillStyle = vgrad(g, 0, 12 * u, 64 * u, body, shade(body, -0.18));
          g.fill();
          // rotulo
          g.fillStyle = 'rgba(255,255,255,0.55)';
          g.fillRect(20 * u, 36 * u, 32 * u, 12 * u);
          g.fillStyle = 'rgba(30,60,90,0.45)';
          g.fillRect(20 * u, 40 * u, 32 * u, 3 * u);
          // gargalo
          g.fillStyle = cap;
          rrect(g, 27 * u, 8 * u, 18 * u, 7 * u, 2.5 * u);
          g.fill();
          // brilho
          g.fillStyle = 'rgba(255,255,255,0.65)';
          rrect(g, 24 * u, 38 * u, 4 * u, 22 * u, 2 * u);
          g.fill();
          break;
        }
        case 1: { // lata de aluminio
          const p = () => rrect(g, 22 * u, 16 * u, 28 * u, 44 * u, 5 * u);
          sticker(g, p, u);
          g.fillStyle = vgrad(g, 0, 16 * u, 60 * u, lighten(body, 0.25), shade(body, -0.22));
          g.fill();
          g.fillStyle = cap;
          ellipsePath(g, 36 * u, 16 * u, 14 * u, 4.6 * u);
          g.fill();
          g.fillStyle = 'rgba(255,255,255,0.5)';
          ellipsePath(g, 36 * u, 15 * u, 11 * u, 3.4 * u);
          g.fill();
          g.fillStyle = 'rgba(60,70,80,0.75)';
          ellipsePath(g, 36 * u, 14 * u, 3.4 * u, 1.5 * u);
          g.fill();
          g.fillStyle = 'rgba(255,255,255,0.7)';
          rrect(g, 25 * u, 24 * u, 4 * u, 28 * u, 2 * u);
          g.fill();
          g.fillStyle = 'rgba(40,60,80,0.35)';
          g.fillRect(22 * u, 32 * u, 28 * u, 5 * u);
          break;
        }
        case 2: { // papelao dobrado
          const p = () => {
            g.beginPath();
            g.moveTo(14 * u, 24 * u);
            g.lineTo(58 * u, 24 * u);
            g.lineTo(58 * u, 58 * u);
            g.lineTo(14 * u, 58 * u);
            g.closePath();
          };
          sticker(g, p, u);
          g.fillStyle = vgrad(g, 0, 24 * u, 58 * u, lighten(body, 0.1), shade(body, -0.2));
          g.fill();
          // abas abertas
          g.fillStyle = shade(body, -0.3);
          g.beginPath();
          g.moveTo(14 * u, 24 * u);
          g.lineTo(24 * u, 12 * u);
          g.lineTo(48 * u, 12 * u);
          g.lineTo(58 * u, 24 * u);
          g.closePath();
          g.fill();
          g.fillStyle = shade(body, -0.14);
          g.beginPath();
          g.moveTo(14 * u, 24 * u);
          g.lineTo(4 * u, 12 * u);
          g.lineTo(24 * u, 12 * u);
          g.closePath();
          g.fill();
          g.beginPath();
          g.moveTo(58 * u, 24 * u);
          g.lineTo(68 * u, 12 * u);
          g.lineTo(48 * u, 12 * u);
          g.closePath();
          g.fill();
          // fita e corrugado
          g.fillStyle = 'rgba(255,255,255,0.22)';
          g.fillRect(32 * u, 12 * u, 8 * u, 46 * u);
          g.strokeStyle = 'rgba(0,0,0,0.16)';
          g.lineWidth = 1.4 * u;
          for (let i = 0; i < 4; i++) {
            g.beginPath();
            g.moveTo(14 * u, (30 + i * 8) * u);
            g.lineTo(58 * u, (30 + i * 8) * u);
            g.stroke();
          }
          break;
        }
        case 3: { // copo de vidro
          const p = () => {
            g.beginPath();
            g.moveTo(24 * u, 12 * u);
            g.lineTo(48 * u, 12 * u);
            g.lineTo(42 * u, 62 * u);
            g.lineTo(30 * u, 62 * u);
            g.closePath();
          };
          sticker(g, p, u);
          g.fillStyle = vgrad(g, 0, 12 * u, 62 * u, lighten(body, 0.35), shade(body, -0.1));
          g.fill();
          g.fillStyle = 'rgba(255,255,255,0.75)';
          g.fillRect(26 * u, 14 * u, 4 * u, 42 * u);
          g.strokeStyle = 'rgba(255,255,255,0.6)';
          g.lineWidth = 2 * u;
          g.beginPath();
          g.ellipse(36 * u, 12 * u, 12 * u, 3.6 * u, 0, 0, Math.PI * 2);
          g.stroke();
          break;
        }
        case 4: { // garrafa de vidro
          const p = () => {
            g.beginPath();
            g.moveTo(32 * u, 8 * u);
            g.lineTo(40 * u, 8 * u);
            g.lineTo(40 * u, 20 * u);
            g.quadraticCurveTo(52 * u, 28 * u, 52 * u, 40 * u);
            g.lineTo(52 * u, 60 * u);
            g.lineTo(20 * u, 60 * u);
            g.lineTo(20 * u, 40 * u);
            g.quadraticCurveTo(20 * u, 28 * u, 32 * u, 20 * u);
            g.closePath();
          };
          sticker(g, p, u);
          g.fillStyle = vgrad(g, 0, 8 * u, 60 * u, lighten(body, 0.3), shade(body, -0.28));
          g.fill();
          g.fillStyle = cap;
          rrect(g, 30 * u, 4 * u, 12 * u, 7 * u, 2 * u);
          g.fill();
          g.fillStyle = 'rgba(255,255,255,0.22)';
          rrect(g, 25 * u, 44 * u, 22 * u, 14 * u, 2 * u);
          g.fill();
          g.fillStyle = 'rgba(255,255,255,0.55)';
          rrect(g, 24 * u, 30 * u, 4 * u, 24 * u, 2 * u);
          g.fill();
          break;
        }
        case 5: { // casca de banana
          const p = () => {
            g.beginPath();
            g.moveTo(16 * u, 56 * u);
            g.quadraticCurveTo(30 * u, 8 * u, 56 * u, 16 * u);
            g.quadraticCurveTo(40 * u, 26 * u, 30 * u, 58 * u);
            g.closePath();
          };
          sticker(g, p, u);
          g.fillStyle = vgrad(g, 0, 10 * u, 58 * u, lighten(body, 0.2), shade(body, -0.16));
          g.fill();
          g.strokeStyle = cap;
          g.lineWidth = 3 * u;
          g.beginPath();
          g.moveTo(18 * u, 54 * u);
          g.quadraticCurveTo(32 * u, 20 * u, 54 * u, 17 * u);
          g.stroke();
          break;
        }
        case 6: { // pao amanhecido
          const p = () => ellipsePath(g, 36 * u, 38 * u, 24 * u, 17 * u);
          sticker(g, p, u);
          g.fillStyle = vgrad(g, 0, 21 * u, 55 * u, lighten(body, 0.22), shade(body, -0.24));
          g.fill();
          g.strokeStyle = cap;
          g.lineWidth = 3 * u;
          for (let i = -1; i <= 1; i++) {
            g.beginPath();
            g.moveTo((28 + i * 12) * u, 30 * u);
            g.lineTo((34 + i * 12) * u, 38 * u);
            g.stroke();
          }
          g.fillStyle = 'rgba(255,255,255,0.2)';
          ellipsePath(g, 30 * u, 30 * u, 8 * u, 4 * u, -0.4);
          g.fill();
          break;
        }
        case 7: { // folha seca
          const p = () => {
            g.beginPath();
            g.moveTo(16 * u, 54 * u);
            g.quadraticCurveTo(28 * u, 8 * u, 58 * u, 14 * u);
            g.quadraticCurveTo(44 * u, 60 * u, 16 * u, 54 * u);
            g.closePath();
          };
          sticker(g, p, u);
          g.fillStyle = vgrad(g, 0, 12 * u, 56 * u, lighten(body, 0.18), shade(body, -0.22));
          g.fill();
          g.strokeStyle = cap;
          g.lineWidth = 2.4 * u;
          g.beginPath();
          g.moveTo(17 * u, 53 * u);
          g.lineTo(56 * u, 15 * u);
          g.stroke();
          g.lineWidth = 1.4 * u;
          for (let i = 1; i <= 3; i++) {
            const t = i / 4;
            const x = 17 + (56 - 17) * t;
            const y = 53 + (15 - 53) * t;
            g.beginPath();
            g.moveTo(x, y);
            g.lineTo(x + 7 * u, y - 4 * u);
            g.moveTo(x, y);
            g.lineTo(x - 5 * u, y - 5 * u);
            g.stroke();
          }
          break;
        }
        case 8: { // copo descartavel
          const p = () => {
            g.beginPath();
            g.moveTo(20 * u, 18 * u);
            g.lineTo(52 * u, 18 * u);
            g.lineTo(45 * u, 62 * u);
            g.lineTo(27 * u, 62 * u);
            g.closePath();
          };
          sticker(g, p, u);
          g.fillStyle = vgrad(g, 0, 18 * u, 62 * u, '#ffffff', '#cdd8e4');
          g.fill();
          g.strokeStyle = 'rgba(120,150,190,0.55)';
          g.lineWidth = 2.4 * u;
          g.beginPath();
          g.moveTo(24 * u, 40 * u);
          g.lineTo(48 * u, 32 * u);
          g.stroke();
          // tampa abaulada + canudo
          g.fillStyle = cap;
          ellipsePath(g, 36 * u, 18 * u, 18 * u, 6 * u);
          g.fill();
          g.fillStyle = 'rgba(255,255,255,0.55)';
          ellipsePath(g, 31 * u, 17 * u, 8 * u, 2.6 * u);
          g.fill();
          g.strokeStyle = '#e2557a';
          g.lineWidth = 4 * u;
          g.beginPath();
          g.moveTo(40 * u, 18 * u);
          g.lineTo(48 * u, 4 * u);
          g.stroke();
          break;
        }
        case 9: { // embalagem de isopor
          const p = () => rrect(g, 12 * u, 22 * u, 48 * u, 32 * u, 4 * u);
          sticker(g, p, u);
          g.fillStyle = vgrad(g, 0, 22 * u, 54 * u, '#ffffff', '#d8d2bb');
          g.fill();
          g.strokeStyle = 'rgba(160,150,120,0.75)';
          g.lineWidth = 2 * u;
          g.stroke();
          g.fillStyle = 'rgba(150,140,110,0.6)';
          for (let i = 0; i < 7; i++) {
            const x = 18 + (i % 4) * 11;
            const y = 30 + Math.floor(i / 4) * 9;
            g.beginPath();
            g.arc(x * u, y * u, 2.4 * u, 0, Math.PI * 2);
            g.fill();
          }
          break;
        }
        case 10: { // isca de chiclete
          const p = () => ellipsePath(g, 36 * u, 38 * u, 20 * u, 14 * u);
          sticker(g, p, u);
          g.fillStyle = vgrad(g, 0, 24 * u, 52 * u, lighten(body, 0.25), shade(body, -0.2));
          g.fill();
          g.fillStyle = 'rgba(255,255,255,0.7)';
          ellipsePath(g, 30 * u, 33 * u, 7 * u, 3.6 * u, -0.35);
          g.fill();
          g.fillStyle = shade(body, -0.3);
          g.beginPath();
          g.moveTo(16 * u, 44 * u);
          g.quadraticCurveTo(36 * u, 58 * u, 56 * u, 44 * u);
          g.quadraticCurveTo(36 * u, 48 * u, 16 * u, 44 * u);
          g.closePath();
          g.fill();
          break;
        }
        default: { // bitu de cigarro
          const p = () => {
            g.beginPath();
            g.moveTo(12 * u, 32 * u);
            g.lineTo(46 * u, 32 * u);
            g.lineTo(46 * u, 46 * u);
            g.lineTo(12 * u, 46 * u);
            g.closePath();
          };
          sticker(g, p, u);
          g.fillStyle = vgrad(g, 0, 32 * u, 46 * u, '#f2ece0', '#cfc6b2');
          g.fill();
          g.fillStyle = '#c07a3a';
          g.fillRect(46 * u, 32 * u, 14 * u, 14 * u);
          g.fillStyle = 'rgba(0,0,0,0.18)';
          g.fillRect(46 * u, 32 * u, 14 * u, 4 * u);
          g.strokeStyle = '#8d8574';
          g.lineWidth = 2 * u;
          g.beginPath();
          g.moveTo(12 * u, 39 * u);
          g.lineTo(46 * u, 39 * u);
          g.stroke();
          g.fillStyle = 'rgba(70,66,58,0.75)';
          g.fillRect(12 * u, 32 * u, 8 * u, 14 * u);
          break;
        }
      }
    };

    item();
  });
}

// ------------------------------------------------------------- cenario fixo

/** Copa de arvore vista de cima, com sombra propria. */
export function treeSprite(variant) {
  return sprite(`tree:${variant}`, 110, 110, (g) => {
    const c = 55;
    const r = mulberry(100 + variant * 7);
    // sombra
    g.fillStyle = 'rgba(24,42,22,0.22)';
    ellipsePath(g, c + 5, c + 7, 46, 40);
    g.fill();
    // copa em camadas
    for (let i = 0; i < 22; i++) {
      const a = r() * Math.PI * 2;
      const d = r() * 26;
      const rad = 15 + r() * 14;
      const x = c + Math.cos(a) * d;
      const y = c + Math.sin(a) * d * 0.94;
      const shadeF = 0.5 + (1 - (y - c + 40) / 90) * 0.5;
      g.fillStyle = mix('#2f6b32', '#7cc25f', Math.min(1, shadeF * (0.55 + r() * 0.6)));
      g.beginPath();
      g.arc(x, y, rad, 0, Math.PI * 2);
      g.fill();
    }
    // luz de cima
    g.fillStyle = 'rgba(255,255,255,0.16)';
    ellipsePath(g, c - 8, c - 12, 24, 18, -0.5);
    g.fill();
  });
}

/** Banco de praça visto de cima. */
export function benchSprite() {
  return sprite('bench', 96, 96, (g) => {
    g.fillStyle = 'rgba(24,42,22,0.2)';
    rrect(g, 12, 18, 72, 62, 10);
    g.fill();
    // estrutura
    g.fillStyle = '#3d4750';
    rrect(g, 8, 14, 80, 12, 5);
    g.fill();
    rrect(g, 8, 70, 80, 12, 5);
    g.fill();
    // ripas de madeira
    for (let i = 0; i < 3; i++) {
      g.fillStyle = i % 2 ? '#9c6a3f' : '#b17b4b';
      rrect(g, 14, 28 + i * 15, 68, 12, 4);
      g.fill();
    }
    g.fillStyle = 'rgba(255,255,255,0.18)';
    rrect(g, 14, 28, 68, 4, 2);
    g.fill();
  });
}

// ------------------------------------------------------------- cor auxiliar

function hex2rgb(h) {
  const s = h.replace('#', '');
  const v = s.length === 3 ? s.split('').map((c) => c + c).join('') : s;
  return [parseInt(v.slice(0, 2), 16), parseInt(v.slice(2, 4), 16), parseInt(v.slice(4, 6), 16)];
}

function clamp255(v) {
  return Math.max(0, Math.min(255, Math.round(v)));
}

function shade(hex, amt) {
  const [r, g, b] = hex2rgb(hex);
  return `rgb(${clamp255(r + 255 * amt)},${clamp255(g + 255 * amt)},${clamp255(b + 255 * amt)})`;
}

function lighten(hex, amt) {
  return shade(hex, amt);
}

function mix(a, b, t) {
  const A = hex2rgb(a);
  const B = hex2rgb(b);
  return `rgb(${clamp255(A[0] + (B[0] - A[0]) * t)},${clamp255(A[1] + (B[1] - A[1]) * t)},${clamp255(A[2] + (B[2] - A[2]) * t)})`;
}

function mulberry(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export { shade, lighten, mix };
