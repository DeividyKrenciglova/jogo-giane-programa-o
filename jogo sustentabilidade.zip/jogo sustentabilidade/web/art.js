// Utilitarios de desenho compartilhados entre cenario, objetos e HUD.

export const TAU = Math.PI * 2;

export function shadow(ctx, x, y, rx, ry, alpha = 0.2) {
  ctx.save();
  ctx.fillStyle = `rgba(26,36,28,${alpha})`;
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, TAU);
  ctx.fill();
  ctx.restore();
}

/** Contorno tracejado para indicar objeto clicavel. */
export function glow(ctx, x, y, w, h, color) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = 3;
  ctx.setLineDash([8, 6]);
  ctx.beginPath();
  ctx.roundRect(x - 3, y - 3, w + 6, h + 6, 12);
  ctx.stroke();
  ctx.restore();
}

/** Etiqueta flutuante, sempre com fundo para o texto ser legivel. */
export function tag(ctx, x, y, label, opts = {}) {
  const { bg = 'rgba(20,28,34,0.86)', fg = '#eef3f6', size = 12, y0 = 0 } = opts;
  ctx.font = `bold ${size}px system-ui, sans-serif`;
  ctx.textAlign = 'center';
  const w = ctx.measureText(label).width + 16;
  const h = size + 12;
  const yy = y - h - y0;
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.roundRect(x - w / 2, yy, w, h, 7);
  ctx.fill();
  // pontinha
  ctx.beginPath();
  ctx.moveTo(x - 5, yy + h - 1);
  ctx.lineTo(x + 5, yy + h - 1);
  ctx.lineTo(x, yy + h + 7);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = fg;
  ctx.fillText(label, x, yy + size + 3);
  ctx.textAlign = 'left';
}

export function wrapText(ctx, text, x, y, maxW, lh) {
  const words = String(text).split(' ');
  let line = '';
  let yy = y;
  for (const word of words) {
    const test = line ? `${line} ${word}` : word;
    if (ctx.measureText(test).width > maxW && line) {
      ctx.fillText(line, x, yy);
      line = word;
      yy += lh;
    } else {
      line = test;
    }
  }
  if (line) ctx.fillText(line, x, yy);
  return yy;
}

export function roundRect(ctx, x, y, w, h, r, fill, stroke) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.stroke();
  }
}

export function mulberry(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Emblema circular com as cores de uma lixeira. */
export function badge(ctx, x, y, r, color, label) {
  ctx.fillStyle = 'rgba(16,22,28,0.85)';
  ctx.beginPath();
  ctx.arc(x, y, r, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = color;
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.fillStyle = color;
  ctx.font = `bold ${Math.round(r * 0.72)}px system-ui, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, x, y + 1);
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
}

/** Escurece um pouco as bordas, para focar o olho no centro. */
export function vignette(ctx, w, h, strength = 0.18) {
  const g = ctx.createRadialGradient(w / 2, h / 2, h * 0.34, w / 2, h / 2, h * 0.92);
  g.addColorStop(0, 'rgba(0,0,0,0)');
  g.addColorStop(1, `rgba(8,14,18,${strength})`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
}
