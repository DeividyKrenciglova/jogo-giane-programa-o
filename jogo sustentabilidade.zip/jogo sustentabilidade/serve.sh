#!/bin/sh
# Sobe um servidorzinho local. Precisa ser http:// e nao file://,
# porque o navegador bloqueia fetch e modulos em arquivos locais.
set -e

cd "$(dirname "$0")"

if [ ! -f web/jogo.wasm ]; then
  echo "web/jogo.wasm nao existe ainda. Rode ./build.sh primeiro."
  exit 1
fi

PORT="${1:-8080}"

echo "abre http://localhost:$PORT/ no navegador"
echo "para encerrar, aperte Ctrl+C"
echo

if command -v python3 >/dev/null 2>&1; then
  cd web && exec python3 -m http.server "$PORT"
elif command -v python >/dev/null 2>&1; then
  cd web && exec python -m SimpleHTTPServer "$PORT"
else
  echo "precisa de python3 ou python instalado."
  exit 1
fi
