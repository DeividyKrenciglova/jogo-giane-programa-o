# Coleta Certinha — jogo de sustentabilidade em Rust

Jogo de arrastar e soltar sobre coleta seletiva, ambientado em **Ivaiporã - PR**: a
**Praça Espanha** (Largo Marechal Deodoro) e o **Colégio Estadual Barbosa Ferraz**
(Rua Rio Grande do Sul, 1200).

O jogador **arrasta o lixo do chão até a lixeira certa**, conversa com os moradores
para aprender sobre reciclagem, e pode perguntar o que quiser ao NPC de IA.
Não há vidas nem tempo limite: errar apenas ensina.

## Como rodar

Não precisa de Node, npm, Tauri nem compilador C. Só de Rust:

```sh
./build.sh    # compila o Rust para WebAssembly
./serve.sh    # sobe um servidor local
```

Depois abra **http://localhost:8080/** no navegador.

Precisa ser `http://` e não `file://`, porque o navegador bloqueia `fetch` e
módulos ES em arquivos locais.

## Como se joga

| ação | como |
|---|---|
| **pegar e jogar o lixo** | **segure no item, arraste até a lixeira e solte** |
| segurar o item na mão | clique curto no item, sem arrastar |
| largar no lugar | solte longe de qualquer lixeira — o item fica onde você soltou |
| devolver ao chão | `Esc` ou clique fora com o item na mão |
| atalhos das lixeiras | `1`, `2`, `3` com o item na mão |
| conversar | clique na pessoa |
| ler uma placa / entrar no colégio | clique no lugar ou na placa |

- **Azul** — recicláveis: PET, lata, papelão, vidro.
- **Verde** — orgânicos: casca, pão amanhecido, folha seca.
- **Vermelho** — não recicláveis: copo descartável, isopor, chiclete, bitu.

Cada acerto dá pontos, bônus de sequência e uma dica sobre o material. Errar
mostra a lixeira correta e devolve o item ao chão — sem perder vida. A lixeira
certa acende em verde enquanto você arrasta.

## O mapa é real

A cena da praça é montada em cima do **contorno verdadeiro do parque**, dos
**nomes oficiais das ruas** e da **posição real do chafariz**, tudo tirado do
OpenStreetMap:

- parque: `leisure=park`, way 176649484
- chafariz: `amenity=fountain`, node 2059372148
- ruas: Av. Tancredo Neves, Rua Ceará, Av. Pedro Koltun, Rua Profª Diva Proença,
  Largo Marechal Deodoro

As coordenadas foram projetadas para 1280×720 a 9,5 px por metro. Os lugares das
árvores, bancos, lixeiras, moradores e do lixo foram gerados por script para
caberem dentro do polígono do parque sem se sobreporem — veja `src/map_gen.py`,
que reproduz a projeção.

## Por que WebAssembly e não Tauri

A máquina de desenvolvimento não tem compilador C (`gcc`/`cc`), nem `ld`, nem os
objetos de inicialização do glibc (`crt1.o`, `libc.a`), e também não tem
`node`/`npm`. Sem isso não dá para linkar nenhum binário nativo, então:

- **Tauri não é possível** aqui: o `npm` não existe e o `cargo-tauri` não linka.
- **Motores de jogo nativos** (`macroquad`, `ggez`, `raylib`, `sdl2`) também não.
- **Rust → WebAssembly funciona**, porque não depende do sistema do host.

O navegador já é a janela do jogo, então o Tauri seria uma camada a mais sem
benefício aqui. Para um executável de verdade, dava para trocar a ponte de
`web/` por `wgpu` + `winit` reaproveitando `src/lib.rs`.

## Estrutura

```
src/            lógica do jogo, 100% em Rust, zero dependência externa
  lib.rs        estado, arrasto, triagem, pontuação, ABI exportada
  world.rs      layout das duas cenas (posições validadas por script)
  trash.rs      tipos de lixo, lixeiras e o material educativo
  dialogue.rs   conversas dos NPC com fatos reais de Ivaiporã
  text.rs       ponte de strings Rust -> JS
  map_gen.py    gera/projeta os dados do OpenStreetMap
web/            front-end, JavaScript puro, sem build nem dependência
  index.html    página
  bridge.js     chamada das funções do wasm
  main.js       mouse, toque, gesto de arrastar
  render.js     quadro, HUD, diálogo, telas
  map.js        cenário: parque, ruas, chafariz, escola
  sprites.js    sprites pré-renderizados (lixo, árvores, bancos)
  art.js        utilitários de desenho
  ai.js         chat com API compatível com OpenAI
  mapdata.js    dados do mapa real (gerado)
  photos.js     carrega fotos reais se existirem
  assets/       coloque aqui praca-espanha.jpg e barbosa-ferraz.jpg
```

A ponte Rust↔JS é manual: números voltam no valor de retorno das funções
`extern "C"` e as strings passam por um buffer único (`text_ptr` / `text_len`).
Isso dispensa o `wasm-bindgen`, que exigiria compilação nativa.

Os sprites são desenhados **uma vez** em canvas fora da tela, a 2× de resolução,
e depois só copiados — por isso ficam nítidos em qualquer tela e o jogo não
perde desempenho.

## Chat com IA

O botão **Turista IA** abre um painel com um NPC que responde sobre reciclagem e
sobre Ivaiporã. Funciona com qualquer API compatível com OpenAI — OpenAI,
OpenRouter, Groq, Together, Ollama local.

A chave é digitada por você e guardada só em `sessionStorage`, então some quando
a aba fecha.

> **Atenção:** rodando no navegador, a chave fica visível para quem estiver no
> mesmo computador. Use uma chave de estudo ou de valor baixo. Se a API bloquear
> chamadas diretas do navegador (erro de CORS), é preciso um proxy — o ajuste
> fica só no `fetch` de `web/ai.js`.

## Fotos reais

O jogo não precisa de nenhuma imagem: o cenário é desenhado e, no caso da praça,
ainda por cima de dados cartográficos reais. Se você tiver fotos com direito de
uso, veja `web/assets/LEIA-ME.md`: basta soltar `praca-espanha.jpg` e
`barbosa-ferraz.jpg` naquela pasta que elas viram o fundo, com o jogo por cima.
